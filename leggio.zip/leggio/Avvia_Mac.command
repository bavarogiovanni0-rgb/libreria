#!/bin/bash
cd "$(dirname "$0")"
echo "Scarico i libri, ci vorranno alcuni minuti..."
python3 scarica_libri.py && open index.html
