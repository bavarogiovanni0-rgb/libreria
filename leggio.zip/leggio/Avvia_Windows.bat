@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Scarico i libri, ci vorranno alcuni minuti...
where py >nul 2>nul && (py scarica_libri.py) || (python scarica_libri.py)
if errorlevel 1 (echo. & echo Serve Python 3: https://www.python.org/downloads/ & pause & exit /b)
start "" index.html
pause
