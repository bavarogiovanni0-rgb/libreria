(function () {
  'use strict';
  var LIB = window.__LIB;
  var CAT = LIB.catalog || [];
  var BY = {};
  CAT.forEach(function (b) { BY[b.slug] = b; });

  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  function h(tag, attrs, kids) {
    var e = document.createElement(tag);
    for (var k in (attrs || {})) {
      if (k === 'class') e.className = attrs[k];
      else if (k === 'text') e.textContent = attrs[k];
      else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), attrs[k]);
      else e.setAttribute(k, attrs[k]);
    }
    (kids || []).forEach(function (c) { if (c != null) e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return e;
  }
  var store = {
    get: function (k, d) { try { var v = localStorage.getItem('leggio:' + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem('leggio:' + k, JSON.stringify(v)); } catch (e) {} }
  };
  function hash(s) { var n = 0; for (var i = 0; i < s.length; i++) n = (n * 31 + s.charCodeAt(i)) >>> 0; return n; }

  /* ---------------- Categorie (cartelle) ---------------- */
  var CATS = {
    'Classici per ragazzi': [200, '📖'], 'Avventura': [28, '🧭'], 'Pirati e mare': [205, '⚓'],
    'Fantasy e magia': [282, '✨'], 'Fantascienza': [252, '🚀'], 'Fiabe e favole': [338, '🦊'],
    'Miti e poesia': [44, '🏛️'], 'Poesia e poemi': [350, '🪶'], 'Romanzi': [16, '📚'],
    'Novelle e racconti': [160, '✒️'], 'Teatro': [300, '🎭'], 'Filosofia e saggi': [218, '🧠'],
    'Storia e viaggi': [96, '🗺️'], 'Memorie': [322, '✉️'], 'Altri classici': [188, '🗂️'],
    'English': [226, '🇬🇧'], 'Español': [2, '🇪🇸']
  };
  function catMeta(c) { return CATS[c] || [hash(c) % 360, '📕']; }
  function hueOf(b) { return (catMeta(b.cat)[0] + (hash(b.slug) % 44) - 22 + 360) % 360; }

  /* ---------------- Tema ---------------- */
  var THEME_ICON = { light: '☀', sepia: '☕', dark: '☾' };
  function setTheme(t) {
    document.documentElement.dataset.theme = t;
    store.set('theme', t);
    $('#themeBtn').textContent = THEME_ICON[t];
    $$('#segTheme button').forEach(function (b) { b.setAttribute('aria-pressed', b.dataset.v === t); });
  }
  $('#themeBtn').addEventListener('click', function () {
    var order = ['light', 'sepia', 'dark'];
    setTheme(order[(order.indexOf(document.documentElement.dataset.theme) + 1) % 3]);
  });

  /* ---------------- Copertine ---------------- */
  function pattern(i) {
    var s = '';
    if (i === 0) { for (var r = 20; r <= 120; r += 20) s += '<circle cx="50" cy="150" r="' + r + '" fill="none" stroke="currentColor" stroke-width="1.2"/>'; }
    else if (i === 1) { for (var x = -150; x < 150; x += 11) s += '<path d="M' + x + ' 150L' + (x + 150) + ' 0" stroke="currentColor" stroke-width=".8"/>'; }
    else if (i === 2) { for (var a = 0; a < 6; a++) s += '<path d="M' + (a * 20 - 10) + ' 150V' + (70 + (a % 2) * 12) + 'a20 20 0 0 1 40 0V150" fill="none" stroke="currentColor" stroke-width="1"/>'; }
    else { for (var y = 12; y < 150; y += 14) { s += '<path d="M0 ' + y + 'q12.5 -8 25 0t25 0t25 0t25 0" fill="none" stroke="currentColor" stroke-width="1"/>'; } }
    return '<svg class="pat" viewBox="0 0 100 150" preserveAspectRatio="xMidYMid slice" aria-hidden="true">' + s + '</svg>';
  }
  function cover(b) {
    var len = b.title.length;
    var k = len < 14 ? 1.18 : len < 24 ? 1 : len < 34 ? .84 : .72;
    var d = h('div', { class: 'cover', style: '--h:' + hueOf(b) + ';--k:' + k });
    d.innerHTML = pattern(hash(b.slug) % 4) + '<div class="frame"></div>';
    d.appendChild(h('div', { class: 'in' }, [h('div', { class: 'c-author', text: b.author }), h('div', { class: 'c-title', text: b.title }), h('div', { class: 'c-orn' })]));
    return d;
  }

  /* ---------------- Biblioteca scelta ---------------- */
  var state = { lib: store.get('lib', null), q: '' };
  if (state.lib !== 'alunni' && state.lib !== 'prof') state.lib = null;
  var TXT = {
    alunni: { kicker: 'Biblioteca degli alunni · dai 10 anni', title: 'Avventure da leggere,<br><em>quando vuoi tu.</em>',
      lead: 'libri gratis: pirati, fiabe, fantasy, fantascienza e grandi classici. Si aprono e si leggono qui, senza registrazione.' },
    prof: { kicker: 'Biblioteca dei prof', title: 'I grandi classici,<br><em>a portata di pagina.</em>',
      lead: 'libri gratis: poesia, romanzi, novelle, saggi e filosofia della letteratura italiana. Si leggono direttamente nel sito.' }
  };
  function libBooks() { return CAT.filter(function (b) { return b.lib === state.lib; }); }
  function setLib(l) {
    state.lib = l; store.set('lib', l);
    document.documentElement.dataset.lib = l;
    $$('#libSwitch button').forEach(function (b) { b.setAttribute('aria-pressed', b.dataset.lib === l); });
  }
  $$('#libSwitch button, .w-card').forEach(function (b) {
    b.addEventListener('click', function () {
      setLib(b.dataset.lib); state.q = ''; $('#q').value = '';
      if (location.hash && location.hash !== '#/') location.hash = '#/'; else route();
      window.scrollTo(0, 0);
    });
  });

  /* ---------------- Home ---------------- */
  function progressOf(slug) { return (store.get('progress', {}))[slug]; }

  function card(b) {
    var p = progressOf(b.slug);
    var meta = h('p', null, [b.author]);
    if (b.lang !== 'it') meta.appendChild(h('span', { class: 'tag', text: b.lang.toUpperCase() }));
    else if (b.lib === 'alunni') meta.appendChild(h('span', { class: 'tag tag10', text: '10+' }));
    var btn = h('button', { class: 'card', onclick: function () { openModal(b.slug); } }, [
      cover(b), h('div', null, [h('h3', { text: b.title }), meta])
    ]);
    if (p && p.pct > 0) btn.lastChild.appendChild(h('div', { class: 'bar' }, [h('i', { style: 'width:' + Math.round(p.pct * 100) + '%' })]));
    return btn;
  }

  function folderTile(name, count) {
    var m = catMeta(name);
    return h('button', { class: 'folder', style: '--h:' + m[0], onclick: function () { location.hash = '#/cartella/' + encodeURIComponent(name); } }, [
      h('div', { class: 'f-body' }, [
        h('span', { class: 'f-emoji', text: m[1] }),
        h('div', null, [h('div', { class: 'f-name', text: name }), h('div', { class: 'f-count', text: count + (count === 1 ? ' libro' : ' libri') })])
      ])
    ]);
  }

  function renderHome() {
    var books = libBooks();
    var t = TXT[state.lib];
    $('#heroKicker').textContent = t.kicker;
    $('#heroTitle').innerHTML = t.title;
    $('#heroLead').innerHTML = '<span>' + (books.length || '60') + '</span> ' + t.lead;
    var art = $('#heroArt'); art.innerHTML = '';
    var pick = books.filter(function (b) { return b.lang === 'it'; }).sort(function () { return Math.random() - .5; }).slice(0, 3);
    if (!pick.length) pick = [{ slug: 'a', title: 'Pinocchio', author: 'Collodi', cat: 'Fiabe e favole' }, { slug: 'bb', title: 'Il Principe', author: 'Machiavelli', cat: 'Romanzi' }, { slug: 'ccc', title: 'Dracula', author: 'Stoker', cat: 'Avventura' }];
    pick.forEach(function (b) { art.appendChild(cover(b)); });

    renderContinue();
    var q = state.q.trim().toLowerCase();
    var res = $('#results'), fs = $('#foldersSec'), ls = $('#langsSec'), em = $('#emptySec');
    res.hidden = fs.hidden = ls.hidden = em.hidden = true;
    if (!books.length) {
      em.hidden = false; em.innerHTML = '';
      em.appendChild(h('div', { class: 'setup' }, [
        h('h2', { text: 'La biblioteca è ancora vuota' }),
        h('p', { text: 'I libri non sono ancora stati scaricati. Segui la guida (LEGGIMI.txt) per riempire il sito.' })
      ]));
      return;
    }
    if (q) {
      var list = books.filter(function (b) { return (b.title + ' ' + b.author + ' ' + b.cat).toLowerCase().indexOf(q) > -1; });
      res.hidden = false; res.innerHTML = '';
      res.appendChild(h('h2', { class: 'sec-title' }, ['Risultati', h('small', { text: list.length + (list.length === 1 ? ' libro' : ' libri') })]));
      res.appendChild(list.length ? h('div', { class: 'grid' }, list.map(card)) :
        h('div', { class: 'empty' }, [h('strong', { text: 'Nessun libro trovato' }), 'Prova con un altro titolo o autore.']));
      return;
    }
    var it = {}, order = [], other = {}, oorder = [];
    books.forEach(function (b) {
      var tgt = b.lang === 'it' ? it : other, ord = b.lang === 'it' ? order : oorder;
      if (!tgt[b.cat]) { tgt[b.cat] = 0; ord.push(b.cat); }
      tgt[b.cat]++;
    });
    fs.hidden = false;
    $('#folderCount').textContent = order.length + ' cartelle · ' + books.filter(function (b) { return b.lang === 'it'; }).length + ' libri in italiano';
    var f = $('#folders'); f.innerHTML = '';
    order.forEach(function (c) { f.appendChild(folderTile(c, it[c])); });
    if (oorder.length) {
      ls.hidden = false;
      var lf = $('#langFolders'); lf.innerHTML = '';
      oorder.sort().forEach(function (c) { lf.appendChild(folderTile(c, other[c])); });
    }
  }

  function renderContinue() {
    var prog = store.get('progress', {});
    var items = Object.keys(prog).filter(function (s) { return BY[s] && BY[s].lib === state.lib && prog[s].pct > 0.005 && prog[s].pct < 0.995; })
      .sort(function (a, b) { return prog[b].t - prog[a].t; }).slice(0, 8);
    $('#continueSec').hidden = !items.length || !!state.q;
    var row = $('#continueRow'); row.innerHTML = '';
    items.forEach(function (s) {
      var b = BY[s], p = prog[s];
      row.appendChild(h('button', { class: 'cont', onclick: function () { location.hash = '#/libro/' + s; } }, [
        cover(b),
        h('div', { style: 'flex:1;min-width:0' }, [
          h('b', { text: b.title }), h('span', { text: Math.round(p.pct * 100) + '% letto' }),
          h('div', { class: 'bar' }, [h('i', { style: 'width:' + Math.round(p.pct * 100) + '%' })])
        ])
      ]));
    });
  }

  function renderFolder(name) {
    var books = libBooks().filter(function (b) { return b.cat === name; });
    var m = catMeta(name);
    var head = $('#fvHead'); head.innerHTML = '';
    head.style.setProperty('--h', m[0]);
    head.appendChild(h('div', { class: 'badge' }, [h('span', { class: 'f-emoji', text: m[1] })]));
    head.appendChild(h('div', null, [h('h2', { text: name }), h('p', { text: books.length + (books.length === 1 ? ' libro' : ' libri') + ' · ' + (state.lib === 'alunni' ? 'Alunni' : 'Prof') })]));
    var g = $('#fvGrid'); g.innerHTML = '';
    books.forEach(function (b) { g.appendChild(card(b)); });
  }
  $('#folderBack').addEventListener('click', function () { location.hash = '#/'; });

  $('#q').addEventListener('input', function (e) {
    state.q = e.target.value; renderHome();
    if (state.q) $('#q').scrollIntoView({ behavior: 'smooth', block: 'center' });
  });
  $('#surprise').addEventListener('click', function () {
    var b = libBooks(); if (!b.length) return;
    openModal(b[Math.floor(Math.random() * b.length)].slug);
  });

  /* ---------------- Modale ---------------- */
  var modalSlug = null;
  function openModal(slug) {
    var b = BY[slug]; modalSlug = slug;
    $('#mCover').innerHTML = ''; $('#mCover').appendChild(cover(b));
    $('#mGenre').textContent = b.cat + ' · ' + b.lang.toUpperCase();
    $('#mTitle').textContent = b.title;
    $('#mAuthor').textContent = b.author;
    $('#mBlurb').textContent = b.blurb;
    var st = $('#mStats'); st.innerHTML = '';
    var rows = [];
    if (b.year) rows.push(['Anno', b.year < 0 ? Math.abs(b.year) + ' a.C.' : b.year]);
    rows.push(['Lettura', fmtMin(b.minutes)], ['Capitoli', b.chapters], ['Parole', b.words.toLocaleString('it-IT')]);
    rows.forEach(function (x) { st.appendChild(h('div', null, [h('dt', { text: x[0] }), h('dd', { text: String(x[1]) })])); });
    var p = progressOf(slug);
    $('#mRead').textContent = p && p.pct > 0.005 && p.pct < 0.995 ? 'Riprendi (' + Math.round(p.pct * 100) + '%)' : 'Leggi ora';
    $('#modal').hidden = false;
    $('#mRead').focus();
  }
  function closeModal() { $('#modal').hidden = true; modalSlug = null; }
  $$('[data-close]').forEach(function (e) { e.addEventListener('click', closeModal); });
  $('#mRead').addEventListener('click', function () { var s = modalSlug; closeModal(); location.hash = '#/libro/' + s; });
  function fmtMin(m) { return m >= 60 ? Math.floor(m / 60) + ' h ' + (m % 60 ? (m % 60) + ' min' : '') : m + ' min'; }

  /* ---------------- Lettore ---------------- */
  var R = { slug: null, chapters: null, idx: 0, cum: [], total: 1, pct: 0, saveT: 0 };
  var reader = $('#reader'), scroller = $('#rScroll'), page = $('#page');
  var prefs = store.get('prefs', { font: 'serif', fs: 20, lh: '1.75', w: '680' });

  function applyPrefs() {
    reader.dataset.font = prefs.font;
    reader.style.setProperty('--fs', prefs.fs);
    reader.style.setProperty('--lh', prefs.lh);
    reader.style.setProperty('--measure', prefs.w + 'px');
    $('#fsOut').textContent = prefs.fs;
    [['segFont', 'font'], ['segLh', 'lh'], ['segW', 'w']].forEach(function (p) {
      $$('#' + p[0] + ' button').forEach(function (b) { b.setAttribute('aria-pressed', b.dataset.v === String(prefs[p[1]])); });
    });
    store.set('prefs', prefs);
  }
  [['segFont', 'font'], ['segLh', 'lh'], ['segW', 'w']].forEach(function (p) {
    $('#' + p[0]).addEventListener('click', function (e) {
      var v = e.target.dataset && e.target.dataset.v; if (!v) return;
      var frac = fracNow(); prefs[p[1]] = v; applyPrefs(); setFrac(frac);
    });
  });
  $('#segTheme').addEventListener('click', function (e) { if (e.target.dataset.v) setTheme(e.target.dataset.v); });
  $('#fsMinus').addEventListener('click', function () { var f = fracNow(); prefs.fs = Math.max(14, prefs.fs - 1); applyPrefs(); setFrac(f); });
  $('#fsPlus').addEventListener('click', function () { var f = fracNow(); prefs.fs = Math.min(34, prefs.fs + 1); applyPrefs(); setFrac(f); });

  function fracNow() { var m = scroller.scrollHeight - scroller.clientHeight; return m > 0 ? scroller.scrollTop / m : 0; }
  function setFrac(f) { scroller.scrollTop = f * Math.max(0, scroller.scrollHeight - scroller.clientHeight); }

  function esc(s) { return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
  function fmt(s) {
    return esc(s).replace(/(^|[\s(\["“«—])_([^_]+?)_(?=[\s.,;:!?)\]"”»—]|$)/g, '$1<em>$2</em>');
  }

  function loadBook(slug) {
    return new Promise(function (res, rej) {
      if (LIB.books[slug]) return res(LIB.books[slug]);
      var s = document.createElement('script');
      s.src = 'data/' + slug + '.js';
      s.onload = function () { LIB.books[slug] ? res(LIB.books[slug]) : rej(new Error('vuoto')); };
      s.onerror = function () { rej(new Error('file mancante')); };
      document.head.appendChild(s);
    });
  }

  function openBook(slug) {
    var b = BY[slug];
    if (!b) { location.hash = '#/'; return; }
    $('#home').hidden = true; reader.hidden = false;
    document.title = b.title + ' · Leggio';
    $('#rTitle').textContent = b.title; $('#rAuthor').textContent = b.author;
    closePanels(); $('#rBar').classList.remove('hide');
    page.innerHTML = '<div class="loading">Apro il libro…</div>';
    loadBook(slug).then(function (chs) {
      R.slug = slug; R.chapters = chs;
      var w = chs.map(function (c) { return c[2].reduce(function (a, p) { return a + p.length; }, 0); });
      R.total = w.reduce(function (a, b2) { return a + b2; }, 0) || 1;
      R.cum = []; var acc = 0; w.forEach(function (x) { R.cum.push(acc); acc += x; });
      R.w = w;
      buildToc();
      var p = progressOf(slug);
      showChapter(p ? Math.min(p.ch, chs.length - 1) : 0, p ? p.pos : 0);
      scroller.focus({ preventScroll: true });
    }).catch(function () {
      page.innerHTML = '<div class="loading">Questo libro non è stato scaricato. Rilancia lo script di download.</div>';
    });
  }

  function showChapter(i, frac) {
    R.idx = i;
    var c = R.chapters[i], title = c[0], group = c[1], paras = c[2];
    var html = '';
    html += '<p class="kick">' + esc(group || ('Capitolo ' + (i + 1) + ' di ' + R.chapters.length)) + '</p>';
    html += '<h2>' + esc(title) + '</h2><span class="orn"></span>';
    var firstDone = false;
    paras.forEach(function (p) {
      if (/^[\*\s·•\-—_=]{3,}$/.test(p)) { html += '<div class="sep">* * *</div>'; return; }
      if (p.indexOf('\n') > -1) { html += '<p class="verse">' + fmt(p) + '</p>'; return; }
      html += '<p' + (!firstDone ? ' class="first"' : '') + '>' + fmt(p) + '</p>'; firstDone = true;
    });
    var prev = R.chapters[i - 1], next = R.chapters[i + 1];
    html += '<div class="chap-nav"><button id="cPrev"' + (prev ? '' : ' disabled') + '>← ' + (prev ? esc(short(prev[0])) : 'Inizio') + '</button>' +
      '<button class="next" id="cNext"' + (next ? '' : ' disabled') + '>' + (next ? esc(short(next[0])) + ' →' : 'Fine') + '</button></div>';
    page.innerHTML = html;
    var pv = $('#cPrev'), nx = $('#cNext');
    if (prev) pv.onclick = function () { showChapter(i - 1, 0); };
    if (next) nx.onclick = function () { showChapter(i + 1, 0); };
    scroller.scrollTop = 0;
    requestAnimationFrame(function () { setFrac(frac || 0); update(); });
    $$('#tocList button').forEach(function (b, k) { b.removeAttribute('aria-current'); });
    var cur = $('#tocList button[data-i="' + i + '"]');
    if (cur) cur.setAttribute('aria-current', 'true');
    $('#rChap').textContent = title;
  }
  function short(t) { return t.length > 34 ? t.slice(0, 32) + '…' : t; }

  function update() {
    if (!R.chapters) return;
    var f = fracNow();
    var pos = R.cum[R.idx] + R.w[R.idx] * f;
    R.pct = Math.min(1, pos / R.total);
    $('#rBarFill').style.width = (R.pct * 100).toFixed(1) + '%';
    $('#rPct').textContent = Math.round(R.pct * 100) + '%';
    var b = BY[R.slug];
    var left = Math.max(0, Math.round(b.minutes * (1 - R.pct)));
    $('#rLeft').textContent = left > 0 ? fmtMin(left) + ' alla fine' : 'Finito!';
    clearTimeout(R.saveT);
    R.saveT = setTimeout(save, 350);
  }
  function save() {
    if (!R.slug) return;
    var all = store.get('progress', {});
    all[R.slug] = { ch: R.idx, pos: fracNow(), pct: R.pct, t: Date.now() };
    store.set('progress', all);
  }

  var lastTop = 0, ticking = false;
  scroller.addEventListener('scroll', function () {
    if (ticking) return; ticking = true;
    requestAnimationFrame(function () {
      ticking = false;
      var t = scroller.scrollTop, d = t - lastTop;
      if (Math.abs(d) > 14) { $('#rBar').classList.toggle('hide', d > 0 && t > 120); lastTop = t; }
      update();
    });
  }, { passive: true });
  scroller.addEventListener('click', function (e) {
    if (e.target.closest('button,a')) return;
    closePanels();
    var r = scroller.getBoundingClientRect();
    if (e.clientY < r.top + r.height * .3) $('#rBar').classList.remove('hide');
  });
  document.addEventListener('mousemove', function (e) { if (!reader.hidden && e.clientY < 50) $('#rBar').classList.remove('hide'); });

  function buildToc() {
    var nav = $('#tocList'); nav.innerHTML = ''; var lastG = null;
    R.chapters.forEach(function (c, i) {
      if (c[1] && c[1] !== lastG) { nav.appendChild(h('div', { class: 'grp', text: c[1] })); }
      lastG = c[1];
      nav.appendChild(h('button', { 'data-i': i, onclick: function () { closePanels(); showChapter(i, 0); } }, [h('i', { text: String(i + 1) }), h('span', { text: c[0] })]));
    });
  }
  function closePanels() { $('#drawer').hidden = true; $('#scrim').hidden = true; $('#pop').hidden = true; }
  $('#rToc').addEventListener('click', function () {
    var open = $('#drawer').hidden; closePanels(); $('#drawer').hidden = !open; $('#scrim').hidden = !open;
    if (open) { var c = $('#tocList [aria-current]'); if (c) c.scrollIntoView({ block: 'center' }); }
  });
  $('#rSet').addEventListener('click', function () { var open = $('#pop').hidden; closePanels(); $('#pop').hidden = !open; });
  $('#drawerX').addEventListener('click', closePanels);
  $('#scrim').addEventListener('click', closePanels);
  $('#rBack').addEventListener('click', function () { save(); location.hash = '#/'; });

  document.addEventListener('keydown', function (e) {
    if (e.target.tagName === 'INPUT') return;
    if (e.key === 'Escape') {
      if (!$('#modal').hidden) return closeModal();
      if (!reader.hidden) { if (!$('#drawer').hidden || !$('#pop').hidden) closePanels(); else { save(); location.hash = '#/'; } }
    }
    if (!reader.hidden && R.chapters) {
      if (e.key === 'ArrowRight' && R.idx < R.chapters.length - 1) showChapter(R.idx + 1, 0);
      if (e.key === 'ArrowLeft' && R.idx > 0) showChapter(R.idx - 1, 0);
      if (e.key === ' ' && e.target === document.body) { scroller.focus(); }
    }
  });

  /* ---------------- Routing ---------------- */
  var homeY = 0;
  function showOnly(which) {
    $('#welcome').hidden = which !== 'welcome';
    $('#home').hidden = which !== 'home' && which !== 'folder';
    $('#mainView').hidden = which !== 'home';
    $('#folderView').hidden = which !== 'folder';
    reader.hidden = which !== 'reader';
  }
  function route() {
    var hsh = location.hash;
    var m = hsh.match(/^#\/libro\/([\w-]+)/);
    var f = hsh.match(/^#\/cartella\/(.+)/);
    if (m) {
      if (reader.hidden) homeY = window.scrollY;
      var bk = BY[m[1]];
      if (bk && bk.lib !== state.lib) setLib(bk.lib);
      showOnly('reader'); $('#home').hidden = true;
      openBook(m[1]);
      return;
    }
    if (!reader.hidden) save();
    R.slug = null; document.title = 'Leggio · la biblioteca gratuita';
    if (!state.lib) {
      var n = function (l) { return CAT.filter(function (b) { return b.lib === l; }).length; };
      $('#wCountA').textContent = n('alunni') ? n('alunni') + ' libri' : '';
      $('#wCountP').textContent = n('prof') ? n('prof') + ' libri' : '';
      showOnly('welcome'); return;
    }
    setLib(state.lib);
    if (f) { showOnly('folder'); renderFolder(decodeURIComponent(f[1])); window.scrollTo(0, 0); return; }
    showOnly('home'); renderHome(); window.scrollTo(0, homeY);
  }
  window.addEventListener('hashchange', route);

  setTheme(document.documentElement.dataset.theme || 'dark');
  if (state.lib) document.documentElement.dataset.lib = state.lib;
  applyPrefs(); route();
})();
