(function () {
  'use strict';
  var LIB = window.__LIB;
  var CAT = LIB.catalog || [];
  var BY = {};
  CAT.forEach(function (b) { BY[b.slug] = b; });

  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  function h(tag, attrs, kids) {
    var e = document.createElement(tag);
    for (var k in (attrs || {})) {
      if (k === 'class') e.className = attrs[k];
      else if (k === 'text') e.textContent = attrs[k];
      else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), attrs[k]);
      else e.setAttribute(k, attrs[k]);
    }
    (kids || []).forEach(function (c) { if (c != null) e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return e;
  }
  var store = {
    get: function (k, d) { try { var v = localStorage.getItem('leggio:' + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem('leggio:' + k, JSON.stringify(v)); } catch (e) {} }
  };
  function hash(s) { var n = 0; for (var i = 0; i < s.length; i++) n = (n * 31 + s.charCodeAt(i)) >>> 0; return n; }

  /* ---------------- Categorie (cartelle) ---------------- */
  var CATS = {
    'Classici per ragazzi': [200, '📖'], 'Avventura': [28, '🧭'], 'Pirati e mare': [205, '⚓'],
    'Fantasy e magia': [282, '✨'], 'Fantascienza': [252, '🚀'], 'Fiabe e favole': [338, '🦊'],
    'Miti e poesia': [44, '🏛️'], 'Poesia e poemi': [350, '🪶'], 'Romanzi': [16, '📚'],
    'Novelle e racconti': [160, '✒️'], 'Teatro': [300, '🎭'], 'Filosofia e saggi': [218, '🧠'],
    'Storia e viaggi': [96, '🗺️'], 'Memorie': [322, '✉️'], 'Altri classici': [188, '🗂️'],
    'English': [226, '🇬🇧'], 'Español': [2, '🇪🇸']
  };
  function catMeta(c) { return CATS[c] || [hash(c) % 360, '📕']; }
  function hueOf(b) { return (catMeta(b.cat)[0] + (hash(b.slug) % 44) - 22 + 360) % 360; }

  /* ---------------- Tema ---------------- */
  var THEME_ICON = { light: '☀', sepia: '☕', dark: '☾' };
  var themeT = 0;
  function setTheme(t) {
    var root = document.documentElement;
    if (root.dataset.theme && root.dataset.theme !== t) {
      root.classList.add('theming'); clearTimeout(themeT);
      themeT = setTimeout(function () { root.classList.remove('theming'); }, 800);
    }
    document.documentElement.dataset.theme = t;
    store.set('theme', t);
    $('#themeBtn').textContent = THEME_ICON[t];
    $$('#segTheme button').forEach(function (b) { b.setAttribute('aria-pressed', b.dataset.v === t); });
  }
  $('#themeBtn').addEventListener('click', function () {
    var order = ['light', 'sepia', 'dark'];
    setTheme(order[(order.indexOf(document.documentElement.dataset.theme) + 1) % 3]);
  });

  /* ---------------- Copertine ---------------- */
  function pattern(i) {
    var s = '';
    if (i === 0) { for (var r = 20; r <= 120; r += 20) s += '<circle cx="50" cy="150" r="' + r + '" fill="none" stroke="currentColor" stroke-width="1.2"/>'; }
    else if (i === 1) { for (var x = -150; x < 150; x += 11) s += '<path d="M' + x + ' 150L' + (x + 150) + ' 0" stroke="currentColor" stroke-width=".8"/>'; }
    else if (i === 2) { for (var a = 0; a < 6; a++) s += '<path d="M' + (a * 20 - 10) + ' 150V' + (70 + (a % 2) * 12) + 'a20 20 0 0 1 40 0V150" fill="none" stroke="currentColor" stroke-width="1"/>'; }
    else { for (var y = 12; y < 150; y += 14) { s += '<path d="M0 ' + y + 'q12.5 -8 25 0t25 0t25 0t25 0" fill="none" stroke="currentColor" stroke-width="1"/>'; } }
    return '<svg class="pat" viewBox="0 0 100 150" preserveAspectRatio="xMidYMid slice" aria-hidden="true">' + s + '</svg>';
  }
  function cover(b) {
    var len = b.title.length;
    var k = len < 14 ? 1.18 : len < 24 ? 1 : len < 34 ? .84 : .72;
    var d = h('div', { class: 'cover', style: '--h:' + hueOf(b) + ';--k:' + k });
    d.innerHTML = pattern(hash(b.slug) % 4) + '<div class="frame"></div>';
    d.appendChild(h('div', { class: 'in' }, [h('div', { class: 'c-author', text: b.author }), h('div', { class: 'c-title', text: b.title }), h('div', { class: 'c-orn' })]));
    if (b.cover) {
      var im = new Image(); im.className = 'pic'; im.alt = ''; im.loading = 'lazy';
      im.onload = function () { if (im.naturalWidth > 60) im.classList.add('ok'); else im.remove(); };
      im.onerror = function () { im.remove(); };
      im.src = b.cover; d.appendChild(im);
    }
    return d;
  }

  /* ---------------- Biblioteca scelta ---------------- */
  var state = { lib: store.get('lib', null), q: '' };
  if (state.lib !== 'alunni' && state.lib !== 'prof') state.lib = null;
  var TXT = {
    alunni: { kicker: 'Biblioteca degli alunni · dai 10 anni', title: 'Avventure da leggere,<br><em>quando vuoi tu.</em>',
      lead: 'libri gratis: pirati, fiabe, fantasy, fantascienza e grandi classici. Si aprono e si leggono qui, senza registrazione.' },
    prof: { kicker: 'Biblioteca dei prof', title: 'I grandi classici,<br><em>a portata di pagina.</em>',
      lead: 'libri gratis: poesia, romanzi, novelle, saggi e filosofia della letteratura italiana. Si leggono direttamente nel sito.' }
  };
  function libBooks() { return CAT.filter(function (b) { return b.lib === state.lib; }); }
  function setLib(l) {
    state.lib = l; store.set('lib', l);
    document.documentElement.dataset.lib = l;
    $$('#libSwitch button').forEach(function (b) { b.setAttribute('aria-pressed', b.dataset.lib === l); });
  }
  $$('#libSwitch button, .w-card').forEach(function (b) {
    b.addEventListener('click', function () {
      setLib(b.dataset.lib); state.q = ''; $('#q').value = '';
      if (location.hash !== '#/home') location.hash = '#/home'; else route();
      window.scrollTo(0, 0);
    });
  });

  /* ---------------- Home ---------------- */
  function progressOf(slug) { return (store.get('progress', {}))[slug]; }

  function card(b) {
    var p = progressOf(b.slug);
    var meta = h('p', null, [b.author]);
    if (b.lang !== 'it') meta.appendChild(h('span', { class: 'tag', text: b.lang.toUpperCase() }));
    else if (b.lib === 'alunni') meta.appendChild(h('span', { class: 'tag tag10', text: '10+' }));
    var btn = h('button', { class: 'card', onclick: function () { openModal(b.slug); } }, [
      cover(b), h('div', null, [h('h3', { text: b.title }), meta])
    ]);
    if (p && p.pct > 0) btn.lastChild.appendChild(h('div', { class: 'bar' }, [h('i', { style: 'width:' + Math.round(p.pct * 100) + '%' })]));
    return btn;
  }

  function folderTile(name, count) {
    var m = catMeta(name);
    return h('button', { class: 'folder', style: '--h:' + m[0], onclick: function () { location.hash = '#/cartella/' + encodeURIComponent(name); } }, [
      h('div', { class: 'f-body' }, [
        h('span', { class: 'f-emoji', text: m[1] }),
        h('div', null, [h('div', { class: 'f-name', text: name }), h('div', { class: 'f-count', text: count + (count === 1 ? ' libro' : ' libri') })])
      ])
    ]);
  }

  function renderHome() {
    var books = libBooks();
    var t = TXT[state.lib];
    $('#heroKicker').textContent = t.kicker;
    $('#heroTitle').innerHTML = t.title;
    $('#heroLead').innerHTML = '<span>' + (books.length || '60') + '</span> ' + t.lead;
    var art = $('#heroArt'); art.innerHTML = '';
    var pick = books.filter(function (b) { return b.lang === 'it'; }).sort(function () { return Math.random() - .5; }).slice(0, 3);
    if (!pick.length) pick = [{ slug: 'a', title: 'Pinocchio', author: 'Collodi', cat: 'Fiabe e favole' }, { slug: 'bb', title: 'Il Principe', author: 'Machiavelli', cat: 'Romanzi' }, { slug: 'ccc', title: 'Dracula', author: 'Stoker', cat: 'Avventura' }];
    pick.forEach(function (b) { art.appendChild(cover(b)); });

    renderContinue();
    var q = state.q.trim().toLowerCase();
    var res = $('#results'), fs = $('#foldersSec'), ls = $('#langsSec'), em = $('#emptySec');
    res.hidden = fs.hidden = ls.hidden = em.hidden = true;
    if (!books.length) {
      em.hidden = false; em.innerHTML = '';
      em.appendChild(h('div', { class: 'setup' }, [
        h('h2', { text: 'La biblioteca è ancora vuota' }),
        h('p', { text: 'I libri non sono ancora stati scaricati. Segui la guida (LEGGIMI.txt) per riempire il sito.' })
      ]));
      return;
    }
    if (q) {
      var list = books.filter(function (b) { return (b.title + ' ' + b.author + ' ' + b.cat).toLowerCase().indexOf(q) > -1; });
      res.hidden = false; res.innerHTML = '';
      res.appendChild(h('h2', { class: 'sec-title' }, ['Risultati', h('small', { text: list.length + (list.length === 1 ? ' libro' : ' libri') })]));
      res.appendChild(list.length ? h('div', { class: 'grid' }, list.map(card)) :
        h('div', { class: 'empty' }, [h('strong', { text: 'Nessun libro trovato' }), 'Prova con un altro titolo o autore.']));
      return;
    }
    var it = {}, order = [], other = {}, oorder = [];
    books.forEach(function (b) {
      var tgt = b.lang === 'it' ? it : other, ord = b.lang === 'it' ? order : oorder;
      if (!tgt[b.cat]) { tgt[b.cat] = 0; ord.push(b.cat); }
      tgt[b.cat]++;
    });
    fs.hidden = false;
    $('#folderCount').textContent = order.length + ' cartelle · ' + books.filter(function (b) { return b.lang === 'it'; }).length + ' libri in italiano';
    var f = $('#folders'); f.innerHTML = '';
    order.forEach(function (c) { f.appendChild(folderTile(c, it[c])); });
    if (oorder.length) {
      ls.hidden = false;
      var lf = $('#langFolders'); lf.innerHTML = '';
      oorder.sort().forEach(function (c) { lf.appendChild(folderTile(c, other[c])); });
    }
  }

  function renderContinue() {
    var prog = store.get('progress', {});
    var items = Object.keys(prog).filter(function (s) { return BY[s] && BY[s].lib === state.lib && prog[s].pct > 0.005 && prog[s].pct < 0.995; })
      .sort(function (a, b) { return prog[b].t - prog[a].t; }).slice(0, 8);
    $('#continueSec').hidden = !items.length || !!state.q;
    var row = $('#continueRow'); row.innerHTML = '';
    items.forEach(function (s) {
      var b = BY[s], p = prog[s];
      row.appendChild(h('button', { class: 'cont', onclick: function () { location.hash = '#/libro/' + s; } }, [
        cover(b),
        h('div', { style: 'flex:1;min-width:0' }, [
          h('b', { text: b.title }), h('span', { text: Math.round(p.pct * 100) + '% letto' }),
          h('div', { class: 'bar' }, [h('i', { style: 'width:' + Math.round(p.pct * 100) + '%' })])
        ])
      ]));
    });
  }

  function renderFolder(name) {
    var books = libBooks().filter(function (b) { return b.cat === name; });
    var m = catMeta(name);
    var head = $('#fvHead'); head.innerHTML = '';
    head.style.setProperty('--h', m[0]);
    head.appendChild(h('div', { class: 'badge' }, [h('span', { class: 'f-emoji', text: m[1] })]));
    head.appendChild(h('div', null, [h('h2', { text: name }), h('p', { text: books.length + (books.length === 1 ? ' libro' : ' libri') + ' · ' + (state.lib === 'alunni' ? 'Alunni' : 'Prof') })]));
    var g = $('#fvGrid'); g.innerHTML = '';
    books.forEach(function (b) { g.appendChild(card(b)); });
  }
  $('#folderBack').addEventListener('click', function () { location.hash = '#/home'; });

  $('#q').addEventListener('input', function (e) {
    state.q = e.target.value; renderHome();
    if (state.q) $('#q').scrollIntoView({ behavior: 'smooth', block: 'center' });
  });
  $('#surprise').addEventListener('click', function () {
    var b = libBooks(); if (!b.length) return;
    openModal(b[Math.floor(Math.random() * b.length)].slug);
  });

  /* ---------------- Modale ---------------- */
  var modalSlug = null;
  function openModal(slug) {
    var b = BY[slug]; modalSlug = slug;
    $('#mCover').innerHTML = ''; $('#mCover').appendChild(cover(b));
    $('#mGenre').textContent = b.cat + ' · ' + b.lang.toUpperCase();
    $('#mTitle').textContent = b.title;
    $('#mAuthor').textContent = b.author;
    $('#mBlurb').textContent = b.blurb;
    var st = $('#mStats'); st.innerHTML = '';
    var rows = [];
    if (b.year) rows.push(['Anno', b.year < 0 ? Math.abs(b.year) + ' a.C.' : b.year]);
    rows.push(['Lettura', fmtMin(b.minutes)], ['Capitoli', b.chapters], ['Parole', b.words.toLocaleString('it-IT')]);
    rows.forEach(function (x) { st.appendChild(h('div', null, [h('dt', { text: x[0] }), h('dd', { text: String(x[1]) })])); });
    var p = progressOf(slug);
    $('#mRead').textContent = p && p.pct > 0.005 && p.pct < 0.995 ? 'Riprendi (' + Math.round(p.pct * 100) + '%)' : 'Leggi ora';
    $('#modal').hidden = false;
    $('#mRead').focus();
  }
  function closeModal() { $('#modal').hidden = true; modalSlug = null; }
  $$('[data-close]').forEach(function (e) { e.addEventListener('click', closeModal); });
  $('#mRead').addEventListener('click', function () { var s = modalSlug; closeModal(); location.hash = '#/libro/' + s; });
  function fmtMin(m) { return m >= 60 ? Math.floor(m / 60) + ' h ' + (m % 60 ? (m % 60) + ' min' : '') : m + ' min'; }

  /* ---------------- Lettore a due pagine ---------------- */
  var R = { slug: null, chapters: null, idx: 0, cum: [], total: 1, pct: 0, saveT: 0, page: 0, pages: 1, vw: 0, gap: 48, spread: false, busy: false, trT: 0 };
  var synth = window.speechSynthesis || null, S = { on: false, paused: false, tok: 0, units: [], ui: 0, chunks: [], ci: 0, rt: 0 };
  var reader = $('#reader'), stage = $('#rStage'), book = $('#book'), viewport = $('#viewport'), page = $('#page');
  var prefs = store.get('prefs', { font: 'serif', fs: 20, lh: '1.75', w: '680', tr: 0 });
  if (prefs.tr === undefined) prefs.tr = 0;
  if (!prefs.rate) prefs.rate = 1;
  if (!prefs.vlang) prefs.vlang = 'orig';
  if (!prefs.gender) prefs.gender = 'f';

  function applyPrefs() {
    reader.dataset.font = prefs.font;
    reader.style.setProperty('--fs', prefs.fs);
    reader.style.setProperty('--lh', prefs.lh);
    $('#fsOut').textContent = prefs.fs;
    [['segFont', 'font'], ['segLh', 'lh'], ['segW', 'w'], ['segTr', 'tr'], ['segVoice', 'vlang'], ['segGender', 'gender']].forEach(function (p) {
      $$('#' + p[0] + ' button').forEach(function (b) { b.setAttribute('aria-pressed', b.dataset.v === String(prefs[p[1]])); });
    });
    $('#rTr').setAttribute('aria-pressed', prefs.tr ? 'true' : 'false');
    store.set('prefs', prefs);
  }
  function changePref(fn) { var f = fracNow(); fn(); applyPrefs(); layout(f); }
  [['segFont', 'font'], ['segLh', 'lh'], ['segW', 'w']].forEach(function (p) {
    $('#' + p[0]).addEventListener('click', function (e) {
      var v = e.target.dataset && e.target.dataset.v; if (!v) return;
      changePref(function () { prefs[p[1]] = v; });
    });
  });
  $('#segTheme').addEventListener('click', function (e) { if (e.target.dataset.v) setTheme(e.target.dataset.v); });
  $('#fsMinus').addEventListener('click', function () { changePref(function () { prefs.fs = Math.max(14, prefs.fs - 1); }); });
  $('#fsPlus').addEventListener('click', function () { changePref(function () { prefs.fs = Math.min(34, prefs.fs + 1); }); });

  function fracNow() { return R.pages > 1 ? R.page / (R.pages - 1) : 0; }

  function esc(s) { return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
  function fmt(s) {
    return esc(s).replace(/(^|[\s(\["“«—])_([^_]+?)_(?=[\s.,;:!?)\]"”»—]|$)/g, '$1<em>$2</em>');
  }

  function loadBook(slug) {
    return new Promise(function (res, rej) {
      if (LIB.books[slug]) return res(LIB.books[slug]);
      var s = document.createElement('script');
      s.src = 'data/' + slug + '.js';
      s.onload = function () { LIB.books[slug] ? res(LIB.books[slug]) : rej(new Error('vuoto')); };
      s.onerror = function () { rej(new Error('file mancante')); };
      document.head.appendChild(s);
    });
  }

  /* geometria: una o due pagine, in base allo spazio disponibile */
  function geom() {
    var sw = stage.clientWidth, sh = stage.clientHeight;
    var fs = prefs.fs, lhpx = fs * parseFloat(prefs.lh);
    var wide = sw > 700;
    var arrows = wide ? 78 : 10, padX = wide ? 50 : 20, padY = wide ? 36 : 22;
    var innerW = sw - arrows * 2 - padX * 2;
    var measure = parseInt(prefs.w, 10);
    var spread = innerW >= 760;
    var gap = spread ? 70 : 40;
    var colW = spread ? Math.min(measure, Math.floor((innerW - gap) / 2)) : Math.min(measure, innerW);
    var vw = spread ? colW * 2 + gap : colW;
    var vh = Math.max(lhpx * 4, Math.floor((sh - 14 - padY * 2) / lhpx) * lhpx);
    var s = book.style;
    s.setProperty('--bw', (vw + padX * 2) + 'px'); s.setProperty('--bh', (vh + padY * 2) + 'px');
    s.setProperty('--px', padX + 'px'); s.setProperty('--py', padY + 'px');
    s.setProperty('--vw', vw + 'px'); s.setProperty('--vh', vh + 'px');
    s.setProperty('--cols', spread ? 2 : 1); s.setProperty('--gap', gap + 'px');
    book.classList.toggle('spread', spread);
    R.vw = vw; R.gap = gap; R.spread = spread;
  }

  /* impagina il capitolo corrente; frac = posizione 0..1, oppure keepPage = indice di pagina */
  function layout(frac, keepPage) {
    if (reader.hidden) return;
    geom();
    if (!R.chapters) return;
    page.style.transition = 'none'; page.style.transform = 'none';
    var w = page.scrollWidth;
    R.pages = Math.max(1, Math.ceil((w + R.gap) / (R.vw + R.gap) - 0.03));
    var n = keepPage != null ? keepPage : Math.round((frac || 0) * (R.pages - 1));
    R.page = Math.max(0, Math.min(R.pages - 1, n));
    setPage(R.page, false);
  }

  function setPage(n, animate, dir) {
    R.page = n;
    page.style.transition = animate ? '' : 'none';
    page.style.transform = 'translateX(' + (-n * (R.vw + R.gap)) + 'px)';
    if (animate) {
      R.busy = true;
      var cls = dir > 0 ? 'turn-next' : 'turn-prev';
      book.classList.remove('turn-next', 'turn-prev'); $('#sweep').className = 'sweep';
      void book.offsetWidth;
      book.classList.add(cls); $('#sweep').className = 'sweep go-' + (dir > 0 ? 'next' : 'prev');
      setTimeout(function () { R.busy = false; book.classList.remove('turn-next', 'turn-prev'); }, 640);
    }
    update();
    maybeTranslate();
  }

  function openBook(slug) {
    var b = BY[slug];
    if (!b) { location.hash = '#/'; return; }
    $('#home').hidden = true; reader.hidden = false;
    document.title = b.title + ' · Leggio';
    $('#rTitle').textContent = b.title; $('#rAuthor').textContent = b.author;
    var foreign = b.lang !== 'it';
    $('#rTr').hidden = !foreign; $('#trRow').hidden = !foreign; $('#voiceRow').hidden = !foreign;
    $('#rSpeak').hidden = !synth;
    stopSpeak();
    page.setAttribute('lang', b.lang || 'it');
    closePanels();
    R.chapters = null; R.pages = 1; R.page = 0;
    book.classList.remove('opening'); void book.offsetWidth; book.classList.add('opening');
    geom();
    page.style.transition = 'none'; page.style.transform = 'none';
    page.innerHTML = '<div class="loading">Apro il libro…</div>';
    loadBook(slug).then(function (chs) {
      R.slug = slug; R.chapters = chs;
      var w = chs.map(function (c) { return c[2].reduce(function (a, p) { return a + p.length; }, 0); });
      R.total = w.reduce(function (a, b2) { return a + b2; }, 0) || 1;
      R.cum = []; var acc = 0; w.forEach(function (x) { R.cum.push(acc); acc += x; });
      R.w = w;
      buildToc();
      var p = progressOf(slug);
      showChapter(p ? Math.min(p.ch, chs.length - 1) : 0, p ? p.pos : 0);
      stage.focus({ preventScroll: true });
    }).catch(function () {
      page.innerHTML = '<div class="loading">Questo libro non è stato scaricato. Rilancia lo script di download.</div>';
    });
  }

  function showChapter(i, frac) {
    R.idx = i;
    var c = R.chapters[i], title = c[0], group = c[1], paras = c[2];
    var html = '';
    html += '<p class="kick">' + esc(group || ('Capitolo ' + (i + 1) + ' di ' + R.chapters.length)) + '</p>';
    html += '<h2>' + esc(title) + '</h2><span class="orn"></span>';
    var firstDone = false;
    paras.forEach(function (p) {
      if (/^[\*\s·•\-—_=]{3,}$/.test(p)) { html += '<div class="sep">* * *</div>'; return; }
      if (p.indexOf('\n') > -1) { html += '<p class="verse">' + fmt(p) + '</p>'; return; }
      html += '<p' + (!firstDone ? ' class="first"' : '') + '>' + fmt(p) + '</p>'; firstDone = true;
    });
    page.innerHTML = html;
    viewport.classList.remove('fadein'); void viewport.offsetWidth; viewport.classList.add('fadein');
    layout(frac || 0);
    $$('#tocList button').forEach(function (b) { b.removeAttribute('aria-current'); });
    var cur = $('#tocList button[data-i="' + i + '"]');
    if (cur) cur.setAttribute('aria-current', 'true');
    $('#rChap').textContent = title;
  }

  function update() {
    if (!R.chapters) return;
    var f = fracNow();
    var pos = R.cum[R.idx] + R.w[R.idx] * f;
    R.pct = Math.min(1, pos / R.total);
    $('#rBarFill').style.width = (R.pct * 100).toFixed(1) + '%';
    $('#rPct').textContent = Math.round(R.pct * 100) + '%';
    var b = BY[R.slug];
    var left = Math.max(0, Math.round(b.minutes * (1 - R.pct)));
    var step = R.spread ? 2 : 1, a = R.page * step + 1, z = Math.min(R.pages * step, a + step - 1);
    var pg = 'pag. ' + (step === 2 && z > a ? a + '–' + z : a) + ' di ' + R.pages * step;
    $('#rLeft').textContent = pg + ' · ' + (left > 0 ? fmtMin(left) + ' alla fine' : 'Finito!');
    clearTimeout(R.saveT);
    R.saveT = setTimeout(save, 350);
  }
  function save() {
    if (!R.slug || !R.chapters) return;
    var all = store.get('progress', {});
    all[R.slug] = { ch: R.idx, pos: fracNow(), pct: R.pct, t: Date.now() };
    store.set('progress', all);
  }

  /* girare pagina */
  function turn(dir) {
    if (R.busy || !R.chapters) return;
    if (S.on) { S.tok++; if (synth) synth.cancel(); clearTimeout(S.rt); S.rt = setTimeout(function () { if (S.on && !S.paused) loadUnits(); }, 900); }
    var np = R.page + dir;
    if (np >= 0 && np < R.pages) return setPage(np, true, dir);
    if (dir > 0 && R.idx < R.chapters.length - 1) return showChapter(R.idx + 1, 0);
    if (dir < 0 && R.idx > 0) return showChapter(R.idx - 1, 1);
    book.classList.remove('bump'); void book.offsetWidth; book.classList.add('bump');
  }
  $('#tNext').addEventListener('click', function () { turn(1); });
  $('#tPrev').addEventListener('click', function () { turn(-1); });
  book.addEventListener('click', function (e) {
    if (e.target.closest('button,a')) return;
    closePanels();
    var r = book.getBoundingClientRect(), x = (e.clientX - r.left) / r.width;
    if (x < .22) turn(-1); else if (x > .78) turn(1);
  });
  var tx = null;
  stage.addEventListener('touchstart', function (e) { var t = e.touches[0]; tx = { x: t.clientX, y: t.clientY }; }, { passive: true });
  stage.addEventListener('touchend', function (e) {
    if (!tx) return; var t = e.changedTouches[0], dx = t.clientX - tx.x, dy = t.clientY - tx.y; tx = null;
    if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) * 1.5) turn(dx < 0 ? 1 : -1);
  }, { passive: true });
  var rzT = 0;
  function onResize() { clearTimeout(rzT); rzT = setTimeout(function () { if (!reader.hidden && R.chapters) layout(null, null); }, 160); }
  window.addEventListener('resize', onResize);
  window.addEventListener('orientationchange', onResize);

  /* traduzione in italiano (solo libri in altre lingue) */
  var trCache = {};
  function trChunk(text, from) {
    var key = from + '|' + text;
    if (trCache[key]) return Promise.resolve(trCache[key]);
    var g = 'https://translate.googleapis.com/translate_a/single?client=gtx&sl=' + from + '&tl=it&dt=t&q=' + encodeURIComponent(text);
    return fetch(g).then(function (r) { if (!r.ok) throw 0; return r.json(); })
      .then(function (d) { return d[0].map(function (x) { return x[0]; }).join(''); })
      .catch(function () {
        return fetch('https://api.mymemory.translated.net/get?q=' + encodeURIComponent(text.slice(0, 480)) + '&langpair=' + from + '|it')
          .then(function (r) { return r.json(); }).then(function (d) { return d.responseData.translatedText; });
      })
      .then(function (t) { trCache[key] = t; return t; });
  }
  function splitText(t, max) {
    var parts = t.match(/[^.!?…]+[.!?…]*\s*/g) || [t], out = [], cur = '';
    parts.forEach(function (s) { if ((cur + s).length > max && cur) { out.push(cur); cur = s; } else cur += s; });
    if (cur) out.push(cur);
    return out;
  }
  function trLong(text, from) {
    var chunks = splitText(text, 700), res = [];
    return chunks.reduce(function (pr, c) { return pr.then(function () { return trChunk(c, from).then(function (t) { res.push(t); }); }); }, Promise.resolve())
      .then(function () { return res.join(' '); });
  }
  function visibleParas() {
    var vr = viewport.getBoundingClientRect(), out = [];
    $$('p', page).forEach(function (p) {
      if (p.dataset.tr || p.classList.contains('kick')) return;
      var rs = p.getClientRects();
      for (var i = 0; i < rs.length; i++) {
        var r = rs[i];
        if (r.width > 0 && r.right > vr.left + 4 && r.left < vr.right - 4 && r.bottom > vr.top && r.top < vr.bottom) { out.push(p); break; }
      }
    });
    return out;
  }
  function toast(msg) {
    var t = h('div', { class: 'toast', text: msg }); reader.appendChild(t); setTimeout(function () { t.remove(); }, 3600);
  }
  function maybeTranslate(loops) {
    if (!prefs.tr || !R.slug || BY[R.slug].lang === 'it') return;
    clearTimeout(R.trT);
    R.trT = setTimeout(function () { translateVisible(loops || 0); }, 720);
  }
  function translateVisible(loops) {
    var slug = R.slug, from = BY[slug].lang, ps = visibleParas().slice(0, 16), keep = R.page, fails = 0;
    if (!ps.length) return;
    reader.classList.add('translating');
    var chain = Promise.resolve();
    ps.forEach(function (p) {
      chain = chain.then(function () {
        if (R.slug !== slug || !prefs.tr) return;
        p.dataset.tr = '1';
        return trLong(p.textContent, from).then(function (t) {
          var s = document.createElement('span'); s.className = 'tr'; s.lang = 'it'; s.textContent = t; p.appendChild(s);
        }).catch(function () { delete p.dataset.tr; fails++; });
      });
    });
    chain.then(function () {
      reader.classList.remove('translating');
      if (R.slug !== slug) return;
      if (fails) toast('Traduzione non disponibile: serve una connessione a internet.');
      layout(null, keep);
      if (!fails && loops < 2) maybeTranslate(loops + 1);
    });
  }
  function clearTranslations() {
    $$('.tr', page).forEach(function (s) { s.remove(); });
    $$('p[data-tr]', page).forEach(function (p) { delete p.dataset.tr; });
    layout(null, R.page);
  }
  function setTr(v) {
    prefs.tr = v ? 1 : 0; applyPrefs();
    if (v) { toast('Traduzione in italiano attiva: compare sotto ogni paragrafo.'); maybeTranslate(); }
    else { clearTimeout(R.trT); clearTranslations(); }
  }
  $('#rTr').addEventListener('click', function () { setTr(!prefs.tr); });
  $('#segTr').addEventListener('click', function (e) { var v = e.target.dataset && e.target.dataset.v; if (v != null) setTr(v === '1'); });


  /* ---------------- Voce narrante ---------------- */
  var LANGS = { it: 'it-IT', en: 'en-GB', es: 'es-ES' };
  function vScore(v) { var n = (v.name || '').toLowerCase(), s = 0; if (/premium|enhanced|siri|neural|natural/.test(n)) s += 3; if (v.localService) s += 1; return s; }
  var MALE = /\b(luca|cosimo|giorgio|jorge|diego|juan|carlos|daniel|arthur|oliver|fred|rishi|gordon|reed|thomas|aaron|alex|male|uomo|hombre|masculin)/i;
  var FEMALE = /\b(alice|federica|paola|elsa|silvia|monica|m[oó]nica|paulina|marisol|angelica|soledad|marta|isabela|kate|serena|martha|samantha|karen|moira|tessa|stephanie|susan|female|donna|mujer|femmin)/i;
  function vGender(v) { var n = v.name || ''; if (MALE.test(n)) return 'm'; if (FEMALE.test(n)) return 'f'; return '?'; }
  function pickVoice(lang) {
    var base = (LANGS[lang] || 'it-IT').slice(0, 2);
    var c = synth.getVoices().filter(function (v) { return v.lang && v.lang.toLowerCase().replace('_', '-').indexOf(base) === 0; });
    c.sort(function (a, b) { return vScore(b) - vScore(a); });
    var g = c.filter(function (v) { return vGender(v) === prefs.gender; });
    if (!g.length) g = c.filter(function (v) { return vGender(v) === '?'; });
    return g[0] || c[0] || null;
  }
  function speakLang() { var b = BY[R.slug]; return (b.lang !== 'it' && prefs.vlang === 'it') ? 'it' : b.lang; }
  function plainText(el) {
    var c = el.cloneNode(true);
    $$('.tr', c).forEach(function (x) { x.remove(); });
    return c.textContent.replace(/\s+/g, ' ').trim();
  }
  function unitPage(el) {
    var r = el.getClientRects()[0]; if (!r) return 0;
    var d = r.left - page.getBoundingClientRect().left;
    return Math.max(0, Math.floor((d + 4) / (R.vw + R.gap)));
  }
  function highlight(el) {
    $$('.speaking', page).forEach(function (x) { x.classList.remove('speaking'); });
    if (el) el.classList.add('speaking');
  }
  function setPlayerUI() {
    $('#player').hidden = !S.on; $('#player').classList.toggle('paused', S.paused);
    $('#rSpeak').setAttribute('aria-pressed', S.on ? 'true' : 'false');
    $('#spPlay').innerHTML = S.paused
      ? '<svg viewBox="0 0 24 24" width="22" height="22"><path d="M8 5v14l11-7z" fill="currentColor"/></svg>'
      : '<svg viewBox="0 0 24 24" width="22" height="22"><path d="M7 5h3.5v14H7zM13.5 5H17v14h-3.5z" fill="currentColor"/></svg>';
    $('#spPlay').setAttribute('aria-label', S.paused ? 'Riprendi' : 'Pausa');
    $('#spRate').textContent = (prefs.rate + '').replace('.', ',') + '×';
  }
  function loadUnits() {
    S.units = $$('h2, p', page).filter(function (e) { return !e.classList.contains('kick') && /[A-Za-zÀ-ÿ0-9]/.test(plainText(e)); });
    var i = 0;
    while (i < S.units.length && unitPage(S.units[i]) < R.page) i++;
    S.ui = i; S.chunks = []; S.ci = 0;
    beginUnit();
  }
  function getText(el) {
    var b = BY[R.slug], plain = plainText(el);
    if (b.lang === 'it' || speakLang() !== 'it') return Promise.resolve(plain);
    var ex = el.querySelector('.tr');
    if (ex) return Promise.resolve(ex.textContent);
    return trLong(plain, b.lang).then(function (t) {
      var sp = document.createElement('span'); sp.className = 'tr'; sp.lang = 'it'; sp.textContent = t; el.appendChild(sp);
      el.dataset.tr = '1';
      layout(null, R.page);
      return t;
    });
  }
  function beginUnit() {
    if (!S.on || S.paused) return;
    var tok = ++S.tok;
    if (S.ui >= S.units.length) {
      if (R.idx < R.chapters.length - 1) {
        showChapter(R.idx + 1, 0);
        setTimeout(function () { if (S.on && !S.paused && tok === S.tok) loadUnits(); }, 600);
      } else stopSpeak();
      return;
    }
    var el = S.units[S.ui], pi = unitPage(el);
    if (pi !== R.page && pi < R.pages && pi >= 0) setPage(pi, true, pi > R.page ? 1 : -1);
    highlight(el);
    getText(el).then(function (txt) {
      if (!S.on || tok !== S.tok) return;
      S.chunks = splitText(txt, 170); S.ci = 0; speakNext(tok);
    }).catch(function () {
      if (tok !== S.tok) return;
      toast('Non riesco a tradurre per la voce italiana: serve internet. Scegli "Originale".'); stopSpeak();
    });
  }
  function speakNext(tok) {
    if (!S.on || S.paused || tok !== S.tok) return;
    if (S.ci >= S.chunks.length) { S.ui++; return beginUnit(); }
    var u = new SpeechSynthesisUtterance(S.chunks[S.ci]), lang = speakLang(), v = pickVoice(lang);
    u.lang = LANGS[lang] || 'it-IT'; if (v) u.voice = v; u.rate = prefs.rate;
    u.onend = function () { if (tok !== S.tok) return; S.ci++; speakNext(tok); };
    u.onerror = function (e) { if (tok !== S.tok || (e && (e.error === 'interrupted' || e.error === 'canceled'))) return; S.ci++; speakNext(tok); };
    try { synth.speak(u); } catch (e) { S.ci++; setTimeout(function () { speakNext(tok); }, 50); }
  }
  function startSpeak() {
    if (!synth || !R.chapters) return;
    synth.cancel(); S.on = true; S.paused = false; setPlayerUI(); closePanels();
    loadUnits();
  }
  function pauseSpeak() { S.paused = true; S.tok++; synth.cancel(); setPlayerUI(); }
  function resumeSpeak() { S.paused = false; setPlayerUI(); var tok = ++S.tok; if (S.chunks.length) speakNext(tok); else beginUnit(); }
  function stopSpeak() {
    if (!S.on && !S.paused) { if (synth) synth.cancel(); return; }
    S.on = false; S.paused = false; S.tok++; clearTimeout(S.rt);
    if (synth) synth.cancel();
    highlight(null); setPlayerUI();
  }
  $('#rSpeak').addEventListener('click', function () { if (S.on) stopSpeak(); else startSpeak(); });
  $('#spPlay').addEventListener('click', function () { if (S.paused) resumeSpeak(); else pauseSpeak(); });
  $('#spStop').addEventListener('click', stopSpeak);
  $('#spRate').addEventListener('click', function () {
    var rates = [0.85, 1, 1.15, 1.3], i = rates.indexOf(prefs.rate);
    prefs.rate = rates[(i + 1) % rates.length]; store.set('prefs', prefs); setPlayerUI();
  });
  $('#segVoice').addEventListener('click', function (e) {
    var v = e.target.dataset && e.target.dataset.v; if (!v) return;
    prefs.vlang = v; applyPrefs();
    if (v === 'it' && !prefs.tr) setTr(true);
    if (S.on && !S.paused) { S.tok++; synth.cancel(); S.chunks = []; setTimeout(function () { loadUnits(); }, 200); }
  });
  $('#segGender').addEventListener('click', function (e) {
    var v = e.target.dataset && e.target.dataset.v; if (!v) return;
    prefs.gender = v; applyPrefs();
    var lg = speakLang(), pv = pickVoice(lg);
    if (pv && vGender(pv) !== v) toast('Su questo dispositivo non ho trovato una voce ' + (v === 'm' ? 'maschile' : 'femminile') + ' in questa lingua: uso ' + pv.name + '. Puoi aggiungerne altre in Impostazioni › Accessibilità › Contenuto letto › Voci.');
    if (S.on && !S.paused) { S.tok++; synth.cancel(); S.chunks = []; setTimeout(function () { loadUnits(); }, 200); }
  });
  if (synth && synth.onvoiceschanged !== undefined) synth.onvoiceschanged = function () {};
  window.addEventListener('pagehide', function () { if (synth) synth.cancel(); });

  function buildToc() {
    var nav = $('#tocList'); nav.innerHTML = ''; var lastG = null;
    R.chapters.forEach(function (c, i) {
      if (c[1] && c[1] !== lastG) { nav.appendChild(h('div', { class: 'grp', text: c[1] })); }
      lastG = c[1];
      nav.appendChild(h('button', { 'data-i': i, onclick: function () { closePanels(); showChapter(i, 0); } }, [h('i', { text: String(i + 1) }), h('span', { text: c[0] })]));
    });
  }
  function closePanels() { $('#drawer').hidden = true; $('#scrim').hidden = true; $('#pop').hidden = true; }
  $('#rToc').addEventListener('click', function () {
    var open = $('#drawer').hidden; closePanels(); $('#drawer').hidden = !open; $('#scrim').hidden = !open;
    if (open) { var c = $('#tocList [aria-current]'); if (c) c.scrollIntoView({ block: 'center' }); }
  });
  $('#rSet').addEventListener('click', function () { var open = $('#pop').hidden; closePanels(); $('#pop').hidden = !open; });
  $('#drawerX').addEventListener('click', closePanels);
  $('#scrim').addEventListener('click', closePanels);
  $('#rBack').addEventListener('click', function () { save(); location.hash = '#/home'; });

  document.addEventListener('keydown', function (e) {
    if (e.target.tagName === 'INPUT') return;
    if (e.key === 'Escape') {
      if (!$('#modal').hidden) return closeModal();
      if (!reader.hidden) { if (!$('#drawer').hidden || !$('#pop').hidden) closePanels(); else { save(); location.hash = '#/home'; } }
    }
    if (!reader.hidden && R.chapters) {
      if (e.key === 'ArrowRight' || e.key === 'PageDown' || (e.key === ' ' && !e.shiftKey)) { e.preventDefault(); turn(1); }
      if (e.key === 'ArrowLeft' || e.key === 'PageUp' || (e.key === ' ' && e.shiftKey)) { e.preventDefault(); turn(-1); }
    }
  });

  /* ---------------- Routing ---------------- */
  var homeY = 0;
  function showOnly(which) {
    $('#welcome').hidden = which !== 'welcome';
    $('#home').hidden = which !== 'home' && which !== 'folder';
    $('#mainView').hidden = which !== 'home';
    $('#folderView').hidden = which !== 'folder';
    reader.hidden = which !== 'reader';
  }
  function route() {
    var hsh = location.hash;
    var m = hsh.match(/^#\/libro\/([\w-]+)/);
    var f = hsh.match(/^#\/cartella\/(.+)/);
    if (m) {
      if (reader.hidden) homeY = window.scrollY;
      var bk = BY[m[1]];
      if (bk && bk.lib !== state.lib) setLib(bk.lib);
      showOnly('reader'); $('#home').hidden = true;
      openBook(m[1]);
      return;
    }
    if (!reader.hidden) save();
    stopSpeak();
    R.slug = null; document.title = 'Leggio · la biblioteca gratuita';
    if (!state.lib || !/^#\/(home|cartella)/.test(hsh)) {
      var n = function (l) { return CAT.filter(function (b) { return b.lib === l; }).length; };
      $('#wCountA').textContent = n('alunni') ? n('alunni') + ' libri' : '';
      $('#wCountP').textContent = n('prof') ? n('prof') + ' libri' : '';
      showOnly('welcome'); return;
    }
    setLib(state.lib);
    if (f) { showOnly('folder'); renderFolder(decodeURIComponent(f[1])); window.scrollTo(0, 0); return; }
    showOnly('home'); renderHome(); window.scrollTo(0, homeY);
  }
  window.addEventListener('hashchange', route);

  setTheme(document.documentElement.dataset.theme || 'dark');
  if (state.lib) document.documentElement.dataset.lib = state.lib;
  applyPrefs(); route();
})();
