(function () {
  'use strict';
  var D = [
    { id: 'faro', lvl: 'alunni', e: '🏮', t: 'Il faro di Marta',
      txt: 'Marta abitava con il nonno in un vecchio faro sulla scogliera. Ogni sera, al tramonto, saliva centoventi scalini per accendere la grande lampada. Una notte di tempesta vide una piccola barca che girava in cerchio tra le onde. Subito Marta fece lampeggiare la luce tre volte, come le aveva insegnato il nonno. Il pescatore capì il segnale, trovò il passaggio tra gli scogli e arrivò sano e salvo al porto. La mattina dopo portò a Marta un cesto di pesci e un grazie grandissimo.',
      vf: [['Marta vive con il nonno.', 1], ['Per arrivare alla lampada Marta sale cento scalini.', 0], ['Il pescatore non capisce il segnale.', 0]],
      mc: [['Quando sale Marta sul faro?', ['Al tramonto', 'All’alba', 'A mezzogiorno'], 0], ['Come aiuta la barca?', ['Urla più forte che può', 'Fa lampeggiare la luce tre volte', 'Lancia una corda'], 1]],
      cl: { p: ['Marta abita in un ', ' sulla scogliera. Sale centoventi scalini per accendere la ', '. Alla fine il pescatore le porta un cesto di ', '.'], w: ['faro', 'lampada', 'pesci'], b: ['faro', 'lampada', 'pesci', 'porto'] },
      or: ['Marta vede una barca nella tempesta', 'Fa lampeggiare la luce tre volte', 'Il pescatore arriva al porto', 'Il giorno dopo porta un cesto di pesci'] },
    { id: 'soffitta', lvl: 'alunni', e: '🗝️', t: 'Il segreto della soffitta',
      txt: 'Luca trovò in soffitta una scatola di legno chiusa con un lucchetto rosso. Cercò la chiave per tutto il pomeriggio: sotto il tappeto, nei cassetti, perfino nel cappello del nonno. Alla fine la scoprì dentro il vaso dei fiori, avvolta in un fazzoletto. Nella scatola c’erano vecchie lettere e una mappa disegnata a mano. La mappa portava al grande ciliegio in fondo al giardino, dove Luca scavò e trovò una moneta d’argento.',
      vf: [['Il lucchetto della scatola è rosso.', 1], ['Luca trova la chiave sotto il tappeto.', 0], ['La mappa porta a un ciliegio.', 1]],
      mc: [['Dove si nasconde la chiave?', ['Nel cappello del nonno', 'Nel vaso dei fiori', 'Nei cassetti'], 1], ['Che cosa trova Luca scavando?', ['Una moneta d’argento', 'Una lettera', 'Un anello'], 0]],
      cl: { p: ['Luca trova una scatola in ', '. Nella scatola ci sono lettere e una ', ' che porta al ', '.'], w: ['soffitta', 'mappa', 'ciliegio'], b: ['soffitta', 'mappa', 'ciliegio', 'cantina'] },
      or: ['Luca trova la scatola chiusa', 'Cerca la chiave tutto il pomeriggio', 'Trova la mappa nella scatola', 'Scava sotto il ciliegio'] },
    { id: 'lettera', lvl: 'prof', e: '✉️', t: 'La lettera mai spedita',
      txt: 'Aveva scritto la lettera tre volte, e tre volte l’aveva strappata. Non perché le parole fossero sbagliate, ma perché erano fin troppo giuste: dicevano ciò che da anni evitava di dire a voce. Quella sera la ripose nel cassetto, accanto a quelle degli altri inverni, e uscì a respirare l’aria fredda del cortile, come chi rimanda un verdetto.',
      vf: [['Le parole della lettera erano sbagliate.', 0], ['Non è la prima lettera che finisce nel cassetto.', 1], ['La lettera viene spedita quella sera.', 0]],
      mc: [['Perché strappa la lettera?', ['Ha una brutta calligrafia', 'Dice troppo apertamente ciò che evita di dire', 'Non sa che cosa scrivere'], 1], ['Che cosa suggerisce «come chi rimanda un verdetto»?', ['Esita davanti a una scelta difficile', 'Aspetta una risposta del giudice', 'Ha fretta di decidere'], 0]],
      cl: { p: ['Ha scritto la lettera ', ' volte. La ripone nel ', ' e va a respirare nel ', '.'], w: ['tre', 'cassetto', 'cortile'], b: ['tre', 'cassetto', 'cortile', 'giardino'] },
      or: ['Scrive e strappa la lettera', 'La ripone nel cassetto', 'Esce nel cortile'] }
  ];
  function el(t, c, x) { var e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = x; return e; }
  function shuf(a) { a = a.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function best() { try { return JSON.parse(localStorage.getItem('leggio:giochi') || '{}'); } catch (e) { return {}; } }
  function saveBest(id, s) { var b = best(); if (!(b[id] >= s)) { b[id] = s; try { localStorage.setItem('leggio:giochi', JSON.stringify(b)); } catch (e) {} } }

  function list(root) {
    var b = best();
    root.appendChild(el('p', 'kicker', 'Sala giochi'));
    root.appendChild(el('h1', 'ar-h', 'Leggi, poi metti alla prova la comprensione'));
    var g = el('div', 'ar-grid');
    D.forEach(function (d) {
      var c = el('a', 'ar-card'); c.href = '#/giochi/' + d.id;
      c.appendChild(el('span', 'ar-e', d.e));
      c.appendChild(el('strong', null, d.t));
      c.appendChild(el('span', 'ar-m', (d.lvl === 'prof' ? '🎓 Prof' : '🎒 Alunni 10+') + ' · 4 esercizi' + (b[d.id] != null ? ' · record ' + b[d.id] + '%' : '')));
      g.appendChild(c);
    });
    root.appendChild(g);
  }

  function game(root, d) {
    var tests = [];
    function block(title) { var s = el('section', 'ar-ex'); s.appendChild(el('h2', null, title)); root.appendChild(s); return s; }
    function pick(opts, labels, onSel) {
      var st = { v: null }, row = el('div', 'ar-opts');
      labels.forEach(function (l, i) { var b = el('button', 'ar-opt', l); b.type = 'button'; b.onclick = function () { st.v = i; Array.prototype.forEach.call(row.children, function (x, k) { x.setAttribute('aria-pressed', k === i); }); }; row.appendChild(b); });
      return { st: st, row: row };
    }
    root.appendChild(el('h1', 'ar-h', d.t));
    root.appendChild(el('p', 'ar-text', d.txt));

    var s1 = block('1 · Vero o falso');
    d.vf.forEach(function (q) {
      var r = el('div', 'ar-q'); r.appendChild(el('p', null, q[0]));
      var p = pick(null, ['Vero', 'Falso']); r.appendChild(p.row); s1.appendChild(r);
      tests.push({ n: r, f: function () { return [p.st.v === (q[1] ? 0 : 1) ? 1 : 0, 1]; } });
    });
    var s2 = block('2 · Scegli la risposta giusta');
    d.mc.forEach(function (q) {
      var r = el('div', 'ar-q'); r.appendChild(el('p', null, q[0]));
      var p = pick(null, q[1]); r.appendChild(p.row); s2.appendChild(r);
      tests.push({ n: r, f: function () { return [p.st.v === q[2] ? 1 : 0, 1]; } });
    });
    var s3 = block('3 · Completa il testo'), r3 = el('p', 'ar-cloze'), sels = [];
    d.cl.p.forEach(function (t, i) {
      r3.appendChild(document.createTextNode(t));
      if (i < d.cl.w.length) {
        var s = el('select', 'ar-sel'); s.appendChild(el('option', null, '…')); s.firstChild.value = '';
        shuf(d.cl.b).forEach(function (w) { var o = el('option', null, w); o.value = w; s.appendChild(o); });
        r3.appendChild(s); sels.push(s);
      }
    });
    s3.appendChild(r3);
    tests.push({ n: r3, f: function () { var g = 0; sels.forEach(function (s, i) { if (s.value === d.cl.w[i]) g++; }); return [g, sels.length]; } });
    var s4 = block('4 · Rimetti in ordine la storia'), seq = [], out = el('ol', 'ar-seq'), pool = el('div', 'ar-opts');
    function drawOr() {
      out.innerHTML = ''; pool.innerHTML = '';
      seq.forEach(function (t) { out.appendChild(el('li', null, t)); });
      shuf(d.or).forEach(function (t) { if (seq.indexOf(t) < 0) { var b = el('button', 'ar-opt', t); b.type = 'button'; b.onclick = function () { seq.push(t); drawOr(); }; pool.appendChild(b); } });
    }
    var rs = el('button', 'btn ghost', 'Ricomincia'); rs.type = 'button'; rs.onclick = function () { seq = []; drawOr(); };
    drawOr(); s4.appendChild(out); s4.appendChild(pool); s4.appendChild(rs);
    tests.push({ n: s4, f: function () { return [seq.join('|') === d.or.join('|') ? 1 : 0, 1]; } });

    var res = el('div', 'ar-res'), go = el('button', 'btn primary', 'Controlla le risposte'); go.type = 'button';
    go.onclick = function () {
      var g = 0, m = 0;
      tests.forEach(function (t) { var x = t.f(); g += x[0]; m += x[1]; t.n.classList.toggle('ok', x[0] === x[1]); t.n.classList.toggle('no', x[0] !== x[1]); });
      var pct = Math.round(g / m * 100); saveBest(d.id, pct);
      res.textContent = g + ' su ' + m + ' (' + pct + '%) ' + (pct === 100 ? '🎉 Perfetto!' : 'Rileggi il testo e riprova.');
    };
    root.appendChild(go); root.appendChild(res);
  }

  window.__ARCADE = {
    render: function (hsh) {
      var root = document.getElementById('arcade'); root.innerHTML = '';
      var bar = el('div', 'ar-bar'), back = el('button', 'btn', '← Indietro'); back.type = 'button';
      var m = hsh.match(/^#\/giochi\/(\w+)/), d = null;
      D.forEach(function (x) { if (m && x.id === m[1]) d = x; });
      back.onclick = function () { location.hash = d ? '#/giochi' : '#/home'; };
      bar.appendChild(back); root.appendChild(bar);
      var w = el('div', 'ar-wrap'); root.appendChild(w);
      if (d) game(w, d); else list(w);
      root.scrollTop = 0;
    }
  };
})();
