#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Leggio - scarica i classici di pubblico dominio (Project Gutenberg) e li prepara
per essere letti DENTRO il sito. Due biblioteche: ALUNNI (10+) e PROF.
Per ciascuna: 50 libri in italiano + 5 in inglese + 5 in spagnolo.
Se un titolo dell'elenco non si trova, lo script lo sostituisce con un altro libro
dello stesso tipo preso dal catalogo di Gutenberg, così i numeri tornano.

Uso:   python3 scarica_libri.py
       python3 scarica_libri.py --solo pinocchio,dracula   (prova veloce)
"""
import argparse
import json
import os
import re
import sys
import time
import unicodedata
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
RAW = ROOT / "scaricati"
UA = {"User-Agent": "Leggio/2.0 (lettore scolastico di libri di pubblico dominio)"}
PAUSA = 0.8  # secondi tra un download e l'altro, per essere gentili con Gutenberg
MIN_IT, MAX_ALTRE = 50, 5


def B(lib, cat, slug, gid, title, author, lang, year, kw, blurb, q=None):
    last = author.split()[-1]
    return dict(lib=lib, cat=cat, slug=slug, id=gid, title=title, author=author, lang=lang, year=year,
                kw=kw, blurb=blurb, qs=[q or f"{title} {last}", f"{kw} {last}", kw])


A, P = "alunni", "prof"
CR, AV, PI, FA, FS, FI, MP = ("Classici per ragazzi", "Avventura", "Pirati e mare", "Fantasy e magia",
                              "Fantascienza", "Fiabe e favole", "Miti e poesia")
PO, RO, NO, TE, FIL, ST, ME = ("Poesia e poemi", "Romanzi", "Novelle e racconti", "Teatro",
                               "Filosofia e saggi", "Storia e viaggi", "Memorie")

BOOKS = [
    # ===================== ALUNNI · italiano (10+) =====================
    B(A, CR, "pinocchio", 52484, "Le avventure di Pinocchio", "Carlo Collodi", "it", 1883, "pinocchio",
      "Il burattino di legno che sogna di diventare un bambino vero."),
    B(A, CR, "cuore", None, "Cuore", "Edmondo De Amicis", "it", 1886, "cuore",
      "Un anno di scuola raccontato da Enrico: amicizia, coraggio e buoni sentimenti."),
    B(A, CR, "gian-burrasca", None, "Il giornalino di Gian Burrasca", "Vamba", "it", 1912, "burrasca",
      "Le marachelle esilaranti di un ragazzino che non ne azzecca una."),
    B(A, CR, "giannettino", None, "Il viaggio per l'Italia di Giannettino", "Carlo Collodi", "it", 1880, "giannettino",
      "Un ragazzo scopre l'Italia viaggiando da Nord a Sud."),
    B(A, CR, "heidi", None, "Heidi", "Johanna Spyri", "it", 1880, "heidi",
      "Una bambina sulle Alpi, il nonno burbero e l'amicizia con la natura."),
    B(A, CR, "piccole-donne", None, "Piccole donne", "Louisa May Alcott", "it", 1868, "piccole donne",
      "Le sorelle March crescono insieme tra sogni, litigi e tanto affetto."),
    B(A, CR, "tom-sawyer", None, "Le avventure di Tom Sawyer", "Mark Twain", "it", 1876, "tom sawyer",
      "Scherzi, tesori e una staccionata da pitturare lungo il Mississippi."),
    B(A, CR, "huckleberry-finn", None, "Le avventure di Huckleberry Finn", "Mark Twain", "it", 1884, "huckleberry",
      "Huck e Jim scendono il grande fiume su una zattera."),
    B(A, CR, "canto-di-natale", None, "Canto di Natale", "Charles Dickens", "it", 1843, "natale",
      "Il burbero Scrooge e i tre spiriti del Natale."),
    B(A, CR, "libro-della-giungla", None, "Il libro della giungla", "Rudyard Kipling", "it", 1894, "giungla",
      "Mowgli, il cucciolo d'uomo cresciuto dai lupi."),
    B(A, CR, "don-chisciotte", None, "Don Chisciotte della Mancia", "Miguel de Cervantes", "it", 1605, "chisciotte",
      "Il cavaliere errante che combatte contro i mulini a vento."),
    B(A, AV, "isola-del-tesoro", None, "L'isola del tesoro", "Robert Louis Stevenson", "it", 1883, "tesoro",
      "Pirati, mappe segrete e il famoso Long John Silver."),
    B(A, AV, "robinson-crusoe", None, "Robinson Crusoe", "Daniel Defoe", "it", 1719, "robinson",
      "Il naufrago che sopravvive per anni su un'isola deserta."),
    B(A, AV, "giro-del-mondo", None, "Il giro del mondo in ottanta giorni", "Jules Verne", "it", 1872, "giro del mondo",
      "La scommessa di Phileas Fogg contro il tempo."),
    B(A, AV, "ventimila-leghe", None, "Ventimila leghe sotto i mari", "Jules Verne", "it", 1870, "leghe",
      "Il capitano Nemo e il suo sottomarino Nautilus."),
    B(A, AV, "viaggio-centro-terra", None, "Viaggio al centro della Terra", "Jules Verne", "it", 1864, "centro della terra",
      "Una discesa nel cratere di un vulcano, fino alle viscere del pianeta."),
    B(A, AV, "gulliver", None, "I viaggi di Gulliver", "Jonathan Swift", "it", 1726, "gulliver",
      "Tra i piccoli abitanti di Lilliput e i giganti di Brobdingnag."),
    B(A, PI, "tigri-di-mompracem", None, "Le tigri di Mompracem", "Emilio Salgari", "it", 1900, "mompracem",
      "Sandokan, la Tigre della Malesia, e i suoi pirati."),
    B(A, PI, "pirati-della-malesia", None, "I pirati della Malesia", "Emilio Salgari", "it", 1896, "malesia",
      "Sandokan e Yanez contro il Rajah bianco."),
    B(A, PI, "corsaro-nero", None, "Il Corsaro Nero", "Emilio Salgari", "it", 1898, "corsaro nero",
      "Il signore di Ventimiglia giura vendetta nei Caraibi."),
    B(A, PI, "regina-dei-caraibi", None, "La regina dei Caraibi", "Emilio Salgari", "it", 1901, "caraibi",
      "Honorata, la figlia del Corsaro Nero, sfida il mare."),
    B(A, PI, "jolanda", None, "Jolanda, la figlia del Corsaro Nero", "Emilio Salgari", "it", 1905, "jolanda",
      "Una ragazza coraggiosa tra pirati e prigionie."),
    B(A, PI, "corsaro-rosso", None, "Il Corsaro Rosso", "Emilio Salgari", "it", 1898, "corsaro rosso",
      "Il fratello del Corsaro Nero e le sue battaglie nel golfo del Messico."),
    B(A, PI, "re-del-mare", None, "Il Re del mare", "Emilio Salgari", "it", 1906, "re del mare",
      "Sandokan ritorna per una nuova, pericolosa avventura."),
    B(A, PI, "figlio-corsaro-rosso", None, "Il figlio del Corsaro Rosso", "Emilio Salgari", "it", 1908, "figlio del corsaro",
      "Un erede senza paura contro i nemici della famiglia."),
    B(A, PI, "capitan-tempesta", None, "Capitan Tempesta", "Emilio Salgari", "it", 1905, "tempesta",
      "Battaglie, assedi e un segreto nascosto sotto un'armatura."),
    B(A, PI, "capitano-della-djumna", None, "Il capitano della Djumna", "Emilio Salgari", "it", 1897, "djumna",
      "Una nave, un tesoro e una caccia attraverso l'oceano."),
    B(A, PI, "misteri-jungla-nera", None, "I misteri della jungla nera", "Emilio Salgari", "it", 1895, "jungla",
      "Tremal-Naik, i thugs e la dea Kâli nel cuore dell'India."),
    B(A, PI, "montagna-di-luce", None, "La montagna di luce", "Emilio Salgari", "it", 1902, "montagna di luce",
      "Un famoso diamante e una corsa piena di pericoli."),
    B(A, PI, "minatori-alaska", None, "I minatori dell'Alaska", "Emilio Salgari", "it", 1900, "alaska",
      "La corsa all'oro tra ghiacci, orsi e avventurieri."),
    B(A, PI, "figlio-cacciatore-orsi", None, "Il figlio del cacciatore d'orsi", "Emilio Salgari", "it", 1905, "cacciatore",
      "Un giovane cacciatore nelle terre selvagge del Nord."),
    B(A, PI, "tesoro-paraguay", None, "Il tesoro del presidente del Paraguay", "Emilio Salgari", "it", 1894, "paraguay",
      "Una spedizione nella foresta alla ricerca di un tesoro."),
    B(A, FA, "alice", None, "Alice nel paese delle meraviglie", "Lewis Carroll", "it", 1865, "alice",
      "Giù per la tana del Bianconiglio, in un mondo senza logica."),
    B(A, FA, "barone-di-munchhausen", None, "Le avventure del Barone di Münchhausen", "Rudolf Erich Raspe", "it", 1785,
      "chhausen", "Il barone che racconta le bugie più incredibili."),
    B(A, FA, "mille-e-una-notte", None, "Le mille e una notte", "Anonimo", "it", 1400, "mille e una",
      "Sherazade racconta storie di geni, tappeti volanti e tesori."),
    B(A, FS, "dalla-terra-alla-luna", None, "Dalla Terra alla Luna", "Jules Verne", "it", 1865, "terra alla luna",
      "Un enorme cannone per sparare un proiettile verso la Luna."),
    B(A, FS, "intorno-alla-luna", None, "Intorno alla Luna", "Jules Verne", "it", 1870, "intorno alla luna",
      "Il viaggio dei tre esploratori attorno al nostro satellite."),
    B(A, FS, "meraviglie-del-duemila", None, "Le meraviglie del Duemila", "Emilio Salgari", "it", 1907, "duemila",
      "Due uomini si risvegliano nell'anno 2000, tra invenzioni incredibili."),
    B(A, FI, "c-era-una-volta", None, "C'era una volta", "Luigi Capuana", "it", 1882, "volta",
      "Fiabe italiane piene di re, fate e principesse."),
    B(A, FI, "racconti-delle-fate", None, "I racconti delle fate", "Charles Perrault", "it", 1697, "fate",
      "Cenerentola, Pollicino, il Gatto con gli stivali e altre fiabe."),
    B(A, FI, "fiabe-grimm", None, "Fiabe dei fratelli Grimm", "Fratelli Grimm", "it", 1812, "grimm",
      "Biancaneve, Hänsel e Gretel e le fiabe popolari tedesche."),
    B(A, FI, "fiabe-andersen", None, "Fiabe di Andersen", "Hans Christian Andersen", "it", 1835, "andersen",
      "La Sirenetta, il Brutto anatroccolo e la Piccola fiammiferaia."),
    B(A, FI, "fiabe-pitre", None, "Fiabe e novelle popolari siciliane", "Giuseppe Pitrè", "it", 1875, "pitre",
      "Le fiabe raccontate in Sicilia di generazione in generazione."),
    B(A, FI, "favole-esopo", None, "Favole di Esopo", "Esopo", "it", -550, "esopo",
      "La volpe e l'uva, la cicala e la formica e tante altre."),
    B(A, FI, "favole-la-fontaine", None, "Favole di La Fontaine", "Jean de La Fontaine", "it", 1668, "fontaine",
      "Animali che parlano e insegnano a vivere."),
    B(A, MP, "odissea", None, "Odissea", "Omero", "it", -700, "odissea",
      "Il lungo viaggio di Ulisse per tornare a Itaca."),
    B(A, MP, "iliade", None, "Iliade", "Omero", "it", -750, "iliade",
      "La guerra di Troia e l'ira di Achille."),
    B(A, MP, "eneide", None, "Eneide", "Virgilio", "it", -19, "eneide",
      "Enea fugge da Troia in fiamme e fonda una nuova città."),
    B(A, MP, "metamorfosi", None, "Le metamorfosi", "Ovidio", "it", 8, "metamorfosi",
      "Miti di uomini e dei che si trasformano in piante, animali, stelle."),
    B(A, MP, "fanciullino", None, "Il fanciullino", "Giovanni Pascoli", "it", 1897, "fanciullino",
      "Il poeta come un bambino che guarda il mondo con stupore."),
    B(A, MP, "myricae", None, "Myricae", "Giovanni Pascoli", "it", 1891, "myricae",
      "Brevi poesie su campagna, uccelli e stagioni."),
    B(A, MP, "cantico-delle-creature", None, "Il Cantico delle creature", "San Francesco d'Assisi", "it", 1224, "cantico",
      "La più antica poesia in lingua italiana: una lode alla natura."),
    # ===================== PROF · italiano =====================
    B(P, PO, "divina-commedia", 1000, "La Divina Commedia", "Dante Alighieri", "it", 1320, "commedia",
      "Il viaggio di Dante tra Inferno, Purgatorio e Paradiso."),
    B(P, PO, "vita-nuova", None, "La Vita Nuova", "Dante Alighieri", "it", 1294, "vita nuova",
      "Prosa e versi sull'amore giovanile per Beatrice."),
    B(P, PO, "convivio", None, "Il Convivio", "Dante Alighieri", "it", 1307, "convivio",
      "Dante spiega la filosofia e commenta le sue canzoni."),
    B(P, PO, "canzoniere", None, "Il Canzoniere", "Francesco Petrarca", "it", 1374, "canzoniere",
      "Trecentosessantasei componimenti per Laura."),
    B(P, PO, "orlando-furioso", None, "Orlando furioso", "Ludovico Ariosto", "it", 1516, "orlando",
      "Cavalieri, magie e amori: il poema della fantasia."),
    B(P, PO, "gerusalemme-liberata", None, "La Gerusalemme liberata", "Torquato Tasso", "it", 1581, "gerusalemme",
      "La prima crociata trasformata in epopea."),
    B(P, PO, "canti-leopardi", None, "Canti", "Giacomo Leopardi", "it", 1831, "leopardi",
      "L'Infinito, A Silvia e le grandi poesie di Leopardi."),
    B(P, PO, "il-giorno", None, "Il Giorno", "Giuseppe Parini", "it", 1763, "parini",
      "Una giornata del giovin signore, tra ironia e satira."),
    B(P, PO, "dei-sepolcri", None, "Dei sepolcri", "Ugo Foscolo", "it", 1807, "sepolcri",
      "Il carme sul valore della memoria e delle tombe."),
    B(P, PO, "alcyone", None, "Alcyone", "Gabriele D'Annunzio", "it", 1903, "alcyone",
      "La poesia dell'estate, de La pioggia nel pineto."),
    B(P, PO, "rime-carducci", None, "Rime nuove", "Giosue Carducci", "it", 1887, "carducci",
      "Versi civili e classici dal primo Nobel italiano."),
    B(P, PO, "canti-di-castelvecchio", None, "Canti di Castelvecchio", "Giovanni Pascoli", "it", 1903, "castelvecchio",
      "Il Gelsomino notturno e le poesie della campagna toscana."),
    B(P, RO, "promessi-sposi", 45334, "I promessi sposi", "Alessandro Manzoni", "it", 1840, "promessi",
      "Renzo e Lucia nella Lombardia del Seicento."),
    B(P, RO, "jacopo-ortis", None, "Ultime lettere di Jacopo Ortis", "Ugo Foscolo", "it", 1802, "ortis",
      "Il primo romanzo epistolare italiano."),
    B(P, RO, "malavoglia", None, "I Malavoglia", "Giovanni Verga", "it", 1881, "malavoglia",
      "Una famiglia di pescatori siciliani travolta dalla sfortuna."),
    B(P, RO, "mastro-don-gesualdo", None, "Mastro-don Gesualdo", "Giovanni Verga", "it", 1889, "gesualdo",
      "Ascesa e solitudine di un muratore diventato ricco."),
    B(P, RO, "mattia-pascal", None, "Il fu Mattia Pascal", "Luigi Pirandello", "it", 1904, "pascal",
      "Un uomo ricomincia da capo con un'altra identità."),
    B(P, RO, "uno-nessuno-centomila", None, "Uno, nessuno e centomila", "Luigi Pirandello", "it", 1926, "centomila",
      "Chi siamo davvero, se ognuno ci vede in modo diverso?"),
    B(P, RO, "coscienza-di-zeno", None, "La coscienza di Zeno", "Italo Svevo", "it", 1923, "zeno",
      "Le memorie ironiche di un inetto che vuole smettere di fumare."),
    B(P, RO, "senilita", None, "Senilità", "Italo Svevo", "it", 1898, "senilita",
      "Emilio, Angiolina e un amore pieno di illusioni."),
    B(P, RO, "una-vita", None, "Una vita", "Italo Svevo", "it", 1892, "svevo",
      "Un impiegato di banca e la sua vita senza slancio."),
    B(P, RO, "il-piacere", None, "Il piacere", "Gabriele D'Annunzio", "it", 1889, "piacere",
      "Andrea Sperelli, esteta e seduttore a Roma."),
    B(P, RO, "trionfo-della-morte", None, "Il trionfo della morte", "Gabriele D'Annunzio", "it", 1894, "trionfo",
      "Un amore tormentato e il fascino della morte."),
    B(P, RO, "canne-al-vento", None, "Canne al vento", "Grazia Deledda", "it", 1913, "canne",
      "Un'antica famiglia sarda e il peso del destino."),
    B(P, RO, "elias-portolu", None, "Elias Portolu", "Grazia Deledda", "it", 1903, "portolu",
      "Un giovane sardo diviso tra amore e coscienza."),
    B(P, RO, "piccolo-mondo-antico", None, "Piccolo mondo antico", "Antonio Fogazzaro", "it", 1895, "piccolo mondo",
      "Una famiglia lombarda negli anni del Risorgimento."),
    B(P, RO, "confessioni-di-un-italiano", None, "Le confessioni di un italiano", "Ippolito Nievo", "it", 1867,
      "confessioni", "Il grande romanzo del Risorgimento."),
    B(P, NO, "decameron", None, "Il Decameron", "Giovanni Boccaccio", "it", 1353, "decameron",
      "Cento novelle raccontate da dieci giovani in fuga dalla peste."),
    B(P, NO, "novelle-per-un-anno", None, "Novelle per un anno", "Luigi Pirandello", "it", 1922, "novelle per un anno",
      "Le storie brevi del grande drammaturgo."),
    B(P, NO, "vita-dei-campi", None, "Vita dei campi", "Giovanni Verga", "it", 1880, "vita dei campi",
      "Rosso Malpelo, La Lupa e Cavalleria rusticana."),
    B(P, NO, "novelle-rusticane", None, "Novelle rusticane", "Giovanni Verga", "it", 1883, "rusticane",
      "La roba e altre storie della Sicilia contadina."),
    B(P, NO, "novellino", None, "Il Novellino", "Anonimo", "it", 1300, "novellino",
      "Le prime novelle in volgare italiano."),
    B(P, NO, "fioretti-di-san-francesco", None, "I fioretti di San Francesco", "Anonimo", "it", 1330, "fioretti",
      "Gli episodi più celebri della vita di San Francesco."),
    B(P, TE, "mandragola", None, "La Mandragola", "Niccolò Machiavelli", "it", 1518, "mandragola",
      "La commedia più brillante del Rinascimento."),
    B(P, TE, "mirra", None, "Mirra", "Vittorio Alfieri", "it", 1786, "mirra",
      "Tragedia di una passione proibita."),
    B(P, FIL, "il-principe", None, "Il Principe", "Niccolò Machiavelli", "it", 1532, "principe",
      "Come si conquista e si conserva il potere."),
    B(P, FIL, "discorsi-sopra-la-prima-deca", None, "Discorsi sopra la prima deca di Tito Livio", "Niccolò Machiavelli",
      "it", 1531, "discorsi", "Machiavelli riflette sulla repubblica romana."),
    B(P, FIL, "il-cortegiano", None, "Il Libro del Cortegiano", "Baldassarre Castiglione", "it", 1528, "cortegiano",
      "Dialoghi su come deve essere il perfetto gentiluomo."),
    B(P, FIL, "dialogo-massimi-sistemi", None, "Dialogo sopra i due massimi sistemi del mondo", "Galileo Galilei", "it",
      1632, "massimi sistemi", "Il confronto tra il sistema di Tolomeo e quello di Copernico."),
    B(P, FIL, "il-saggiatore", None, "Il Saggiatore", "Galileo Galilei", "it", 1623, "saggiatore",
      "Il metodo scientifico e il libro della natura scritto in matematica."),
    B(P, FIL, "scienza-nuova", None, "La scienza nuova", "Giambattista Vico", "it", 1725, "scienza nuova",
      "Una nuova filosofia della storia."),
    B(P, FIL, "dei-delitti-e-delle-pene", None, "Dei delitti e delle pene", "Cesare Beccaria", "it", 1764, "delitti",
      "Contro la tortura e la pena di morte."),
    B(P, FIL, "operette-morali", None, "Operette morali", "Giacomo Leopardi", "it", 1827, "operette",
      "Dialoghi filosofici e ironici sul destino dell'uomo."),
    B(P, ST, "storia-d-italia", None, "Storia d'Italia", "Francesco Guicciardini", "it", 1540, "guicciardini",
      "La storia degli anni che sconvolsero l'Italia rinascimentale."),
    B(P, ST, "il-milione", None, "Il Milione", "Marco Polo", "it", 1298, "milione",
      "Il grande viaggio in Oriente."),
    B(P, ST, "storia-colonna-infame", None, "Storia della colonna infame", "Alessandro Manzoni", "it", 1842,
      "colonna infame", "Il processo agli untori durante la peste di Milano."),
    B(P, ST, "vite-vasari", None, "Le vite dei più eccellenti pittori, scultori e architetti", "Giorgio Vasari", "it",
      1550, "vasari", "La storia dell'arte italiana raccontata dagli artisti."),
    B(P, ME, "mie-prigioni", None, "Le mie prigioni", "Silvio Pellico", "it", 1832, "prigioni",
      "Dieci anni di carcere duro raccontati con dolcezza."),
    B(P, ME, "vita-cellini", None, "Vita di Benvenuto Cellini", "Benvenuto Cellini", "it", 1566, "cellini",
      "L'autobiografia avventurosa di un orafo del Rinascimento."),
    B(P, ME, "vita-alfieri", None, "Vita di Vittorio Alfieri", "Vittorio Alfieri", "it", 1803, "alfieri",
      "L'autobiografia di un tragediografo ribelle."),
    # ===================== ALTRE LINGUE · alunni =====================
    B(A, "English", "oz", 55, "The Wonderful Wizard of Oz", "L. Frank Baum", "en", 1900, "oz",
      "Dorothy, la strada di mattoni gialli e il Mago di Oz."),
    B(A, "English", "peter-pan", 16, "Peter Pan", "J. M. Barrie", "en", 1911, "peter pan",
      "Il ragazzo che non voleva crescere."),
    B(A, "English", "secret-garden", 113, "The Secret Garden", "Frances Hodgson Burnett", "en", 1911, "secret garden",
      "Un giardino nascosto che cambia la vita di una bambina."),
    B(A, "English", "black-beauty", 271, "Black Beauty", "Anna Sewell", "en", 1877, "black beauty",
      "La vita di un cavallo raccontata da lui stesso."),
    B(A, "English", "anne-of-green-gables", 45, "Anne of Green Gables", "L. M. Montgomery", "en", 1908, "green gables",
      "Anne, la ragazzina dai capelli rossi e dalla fantasia infinita."),
    B(A, "Español", "cuentos-de-la-selva", None, "Cuentos de la selva", "Horacio Quiroga", "es", 1918, "selva",
      "Animali della giungla argentina che parlano e vivono avventure."),
    B(A, "Español", "fabulas-iriarte", None, "Fábulas literarias", "Tomás de Iriarte", "es", 1782, "iriarte",
      "Favole in versi con la morale in fondo."),
    B(A, "Español", "fabulas-samaniego", None, "Fábulas", "Félix María Samaniego", "es", 1781, "samaniego",
      "Favole di animali che insegnano a vivere."),
    B(A, "Español", "cuentos-de-hadas", None, "Cuentos de hadas", "Hermanos Grimm", "es", 1812, "hadas",
      "Fiabe classiche in spagnolo."),
    B(A, "Español", "viaje-al-centro", None, "Viaje al centro de la Tierra", "Julio Verne", "es", 1864, "centro",
      "Il romanzo di Verne nella traduzione spagnola."),
    # ===================== ALTRE LINGUE · prof =====================
    B(P, "English", "pride-and-prejudice", 1342, "Pride and Prejudice", "Jane Austen", "en", 1813, "pride",
      "Elizabeth Bennet, Mr Darcy e la commedia sentimentale perfetta."),
    B(P, "English", "hamlet", 1524, "Hamlet", "William Shakespeare", "en", 1603, "hamlet",
      "Il principe di Danimarca, un fantasma e una vendetta rimandata."),
    B(P, "English", "frankenstein", 84, "Frankenstein", "Mary Shelley", "en", 1818, "frankenstein",
      "Lo scienziato, la creatura e le conseguenze di un'ossessione."),
    B(P, "English", "moby-dick", 2701, "Moby Dick", "Herman Melville", "en", 1851, "moby",
      "La caccia del capitano Achab alla balena bianca."),
    B(P, "English", "great-expectations", 1400, "Great Expectations", "Charles Dickens", "en", 1861, "great expectations",
      "Le grandi speranze del giovane Pip."),
    B(P, "Español", "don-quijote", 2000, "Don Quijote de la Mancha", "Miguel de Cervantes", "es", 1605, "quijote",
      "Il primo romanzo moderno, nell'originale spagnolo."),
    B(P, "Español", "lazarillo", 320, "Lazarillo de Tormes", "Anonimo", "es", 1554, "lazarillo",
      "Il piccaro che serve padroni sempre più miseri."),
    B(P, "Español", "la-vida-es-sueno", None, "La vida es sueño", "Pedro Calderón de la Barca", "es", 1635, "es sueno",
      "Il principe Segismundo e il grande dramma del barocco spagnolo."),
    B(P, "Español", "rimas-becquer", None, "Rimas y leyendas", "Gustavo Adolfo Bécquer", "es", 1871, "rimas",
      "Poesie d'amore e leggende misteriose del Romanticismo."),
    B(P, "Español", "niebla", None, "Niebla", "Miguel de Unamuno", "es", 1914, "niebla",
      "Un personaggio che si ribella al suo autore."),
]


# ----------------------------------------------------------------------------------------
# Download
# ----------------------------------------------------------------------------------------
def norm(s):
    s = unicodedata.normalize("NFD", s or "")
    return "".join(c for c in s if unicodedata.category(c) != "Mn").lower()


def http_get(url, binary=True, tries=3, timeout=60):
    last = None
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers=UA)
            with urllib.request.urlopen(req, timeout=timeout) as r:
                data = r.read()
            return data if binary else data.decode("utf-8", "replace")
        except Exception as e:  # noqa
            last = e
            time.sleep(1.5 * (i + 1))
    raise last


def decode(b):
    for enc in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            return b.decode(enc)
        except UnicodeDecodeError:
            continue
    return b.decode("utf-8", "replace")


def header_ok(text, kw):
    return norm(kw) in norm(text[:5000])


def id_urls(gid):
    return [f"https://www.gutenberg.org/cache/epub/{gid}/pg{gid}.txt",
            f"https://www.gutenberg.org/ebooks/{gid}.txt.utf-8",
            f"https://www.gutenberg.org/files/{gid}/{gid}-0.txt"]


def fetch_by_id(gid, kw):
    for u in id_urls(gid):
        try:
            t = decode(http_get(u, tries=2))
        except Exception:
            continue
        return t if header_ok(t, kw) else None
    return None


def gutendex(params):
    return json.loads(http_get("https://gutendex.com/books/?" + urllib.parse.urlencode(params),
                               binary=False, tries=3))


def plain_url(r):
    for k, u in r.get("formats", {}).items():
        if k.startswith("text/plain"):
            return u
    return None


def author_name(r):
    a = (r.get("authors") or [{}])[0].get("name") or "Autori vari"
    if "," in a:
        s, n = [x.strip() for x in a.split(",", 1)]
        return f"{n} {s}"
    return a


def fetch_by_search(qs, lang, kw, used):
    for q in qs:
        try:
            res = gutendex({"search": q, "languages": lang})
        except Exception:
            continue
        for r in res.get("results", [])[:10]:
            if r["id"] in used:
                continue
            meta = norm(r.get("title", "") + " " + " ".join(a.get("name", "") for a in r.get("authors", [])))
            if norm(kw) not in meta:
                continue
            u = plain_url(r)
            if not u:
                continue
            try:
                t = decode(http_get(u, tries=2))
            except Exception:
                continue
            if header_ok(t, kw) and len(t) > 8000:
                return t, r["id"]
    return None, None


def get_raw(b, used):
    cache = RAW / f"{b['slug']}.txt"
    if cache.exists():
        return cache.read_text(encoding="utf-8", errors="replace"), None
    text, gid = None, None
    if b["id"] and b["id"] not in used:
        text, gid = fetch_by_id(b["id"], b["kw"]), b["id"]
    if not text:
        text, gid = fetch_by_search(b["qs"], b["lang"], b["kw"], used)
    if text:
        RAW.mkdir(exist_ok=True)
        cache.write_text(text, encoding="utf-8")
        time.sleep(PAUSA)
    return text, gid


def autofill(lib, lang, need, queries, used, cat):
    """Sostituisce i titoli mancanti con altri libri dello stesso tipo presi dal catalogo Gutenberg."""
    out = []
    for params in queries:
        pages, url = 0, None
        while len(out) < need and pages < 8:
            pages += 1
            try:
                res = (gutendex(params) if url is None else json.loads(http_get(url, binary=False, tries=2)))
            except Exception:
                break
            for r in res.get("results", []):
                if len(out) >= need:
                    break
                if r["id"] in used or r.get("languages") != [lang]:
                    continue
                u = plain_url(r)
                if not u:
                    continue
                try:
                    t = decode(http_get(u, tries=2))
                except Exception:
                    continue
                if len(t) < 30000:
                    continue
                used.add(r["id"])
                slug = f"gutenberg-{r['id']}"
                RAW.mkdir(exist_ok=True)
                (RAW / f"{slug}.txt").write_text(t, encoding="utf-8")
                b = dict(lib=lib, cat=cat, slug=slug, id=r["id"], title=re.sub(r"\s+", " ", r["title"]).strip(),
                         author=author_name(r), lang=lang, year=None, kw="",
                         blurb="Un classico di pubblico dominio dalla biblioteca di Project Gutenberg.")
                out.append((b, t))
                time.sleep(PAUSA)
            url = res.get("next")
            if not url:
                break
    return out


# ----------------------------------------------------------------------------------------
# Pulizia e suddivisione in capitoli
# ----------------------------------------------------------------------------------------
ORD = (r"(?:[IVXLCDM]+|\d+|ONE|TWO|THREE|FOUR|FIVE|SIX|SEVEN|EIGHT|NINE|TEN|ELEVEN|TWELVE|FIRST|SECOND|THIRD|"
       r"FOURTH|FIFTH|PRIMO|PRIMA|SECONDO|SECONDA|TERZO|TERZA|QUARTO|QUARTA|QUINTO|SESTO|SETTIMO|OTTAVO|NONO|"
       r"DECIMO|UNO|DUE|TRE|QUATTRO|CINQUE|SEI|SETTE|OTTO|NOVE|DIECI|UNICO|LAST|ULTIMO|ULTIMA|FINAL)")
SUPER = r"(?:BOOK|VOLUME|VOL\.|PART|PARTE|LIBRO|ACT|ATTO|CANTICA|EPOCH|TOMO)"
SUB = r"(?:CHAPTER|CAPITOLO|CAP\.|CANTO|LETTER|LETTERA|SECTION|SCENE|SCENA|STAVE|NOVELLA|GIORNATA|CHAP\.|STANZA)"
RE_KW = re.compile(rf"^(?P<kw>{SUPER}|{SUB})\s+(?P<n>{ORD})\b[\.:,\-—–]?\s*(?P<rest>.*)$", re.I)
RE_SPECIAL = re.compile(r"^(PROLOGUE|EPILOGUE|PREFACE|INTRODUCTION|PREFAZIONE|INTRODUZIONE|PROLOGO|EPILOGO|CONCLUSION|"
                        r"CONCLUSIONE|APPENDIX|APPENDICE|DEDICATION|DEDICA|PROEMIO|PREAMBLE|PROLOGO|"
                        r"INFERNO|PURGATORIO|PARADISO)[\.\:]?$", re.I)
RE_SUPER_SPECIAL = re.compile(r"^(INFERNO|PURGATORIO|PARADISO)[\.\:]?$", re.I)
RE_ROMAN = re.compile(r"^(?=[IVXLCDM])M{0,3}(CM|CD|D?C{0,3})(XC|XL|L?X{0,3})(IX|IV|V?I{0,3})[\.\)]?$")
RE_NUM = re.compile(r"^\d{1,3}[\.\)]?$")
RE_JUNK_TITLE = re.compile(r"^(contents|indice|index|table of contents|illustrations|list of illustrations|"
                           r"elenco delle illustrazioni|sommario)\b", re.I)
RE_ILLU = re.compile(r"^\[(Illustration|Copyright|Transcriber|Footnote|Decorative|Pg|Page)", re.I)


def strip_gutenberg(t):
    t = t.replace("\r\n", "\n").replace("\r", "\n").replace("﻿", "")
    m = re.search(r"\*\*\* ?START OF (?:THE|THIS) PROJECT GUTENBERG EBOOK[^\n]*\n", t, re.I)
    if m:
        t = t[m.end():]
    m = re.search(r"\*\*\* ?END OF (?:THE|THIS) PROJECT GUTENBERG EBOOK", t, re.I)
    if m:
        t = t[:m.start()]
    return t.strip("\n")


def nice(s):
    s = re.sub(r"\s+", " ", s).strip().rstrip(".")
    letters = [c for c in s if c.isalpha()]
    if letters and sum(c.isupper() for c in letters) / len(letters) > 0.8:
        out = []
        for w in s.split(" "):
            if re.fullmatch(r"[IVXLCDM]+[\.,:]?", w):
                out.append(w)
            else:
                out.append(w[:1].upper() + w[1:].lower())
        s = " ".join(out)
    return s


def detect(lines, nxt):
    """Ritorna (tipo, titolo, consumati) con tipo in {'super','sub',None}."""
    if len(lines) > 2:
        return None, None, 0
    first = lines[0]
    joined = " ".join(lines)
    if len(joined) > 90:
        return None, None, 0
    m = RE_KW.match(first)
    if m:
        kind = "super" if re.fullmatch(SUPER, m.group("kw"), re.I) else "sub"
        title = first
        rest = m.group("rest").strip()
        extra = lines[1] if len(lines) == 2 else None
        used = 1
        if extra:
            title = f"{first.rstrip('.')} — {extra.strip()}"
        elif not rest and nxt is not None and len(nxt) == 1:
            n = nxt[0]
            if (len(n) <= 55 and n[:1].isalpha() and n[:1].isupper() and not n.endswith(",")
                    and not RE_KW.match(n) and not RE_ROMAN.match(n) and not RE_SPECIAL.match(n)):
                title = f"{first.rstrip('.')} — {n}"
                used = 2
        elif rest:
            title = re.sub(r"^(\S+\s+\S+?)[\.:,\-—–]\s*", r"\1 — ", first, count=1)
        return kind, nice(title), used
    if len(lines) == 1:
        if RE_SPECIAL.match(first):
            return ("super" if RE_SUPER_SPECIAL.match(first) else "sub"), nice(first), 1
        if RE_ROMAN.match(first) or RE_NUM.match(first):
            title = first.rstrip(".)")
            used = 1
            if nxt is not None and len(nxt) == 1:
                n = nxt[0]
                if (len(n) <= 50 and n[:1].isupper() and n.isupper() and not RE_ROMAN.match(n)):
                    title = f"{title} — {n}"
                    used = 2
            return "sub", nice(title), used
    return None, None, 0


def para_text(lines):
    if len(lines) >= 2 and max(len(l) for l in lines) <= 62:
        return "\n".join(lines)  # versi
    return " ".join(lines)


def words(paras):
    return sum(len(p.split()) for p in paras)


def chunk(paras, target):
    out, cur, w = [], [], 0
    for p in paras:
        cur.append(p)
        w += len(p.split())
        if w >= target:
            out.append(cur)
            cur, w = [], 0
    if cur:
        if out and w < target * 0.3:
            out[-1] += cur
        else:
            out.append(cur)
    return out


def parse_book(raw):
    body = strip_gutenberg(raw)
    blocks = [b for b in re.split(r"\n\s*\n", body) if b.strip()]
    items = []
    for b in blocks:
        lines = [l.strip() for l in b.split("\n") if l.strip()]
        if not lines:
            continue
        j = " ".join(lines)
        if RE_ILLU.match(j) and j.endswith("]"):
            continue
        items.append(lines)

    chapters, cur, group = [], {"title": "Premessa", "group": "", "paras": [], "super": False}, ""

    def flush():
        nonlocal cur
        body_len = sum(len(p) for p in cur["paras"])
        keep = body_len >= 120
        if cur["title"] == "Premessa":
            keep = body_len >= 1500
        if cur.get("super") and not cur["paras"]:
            keep = False
        if keep and not RE_JUNK_TITLE.match(cur["title"]):
            chapters.append(cur)

    i = 0
    while i < len(items):
        nxt = items[i + 1] if i + 1 < len(items) else None
        kind, title, used = detect(items[i], nxt)
        if kind == "super":
            flush()
            group = title
            cur = {"title": title, "group": "", "paras": [], "super": True}
            i += used
            continue
        if kind == "sub":
            flush()
            cur = {"title": title, "group": group, "paras": [], "super": False}
            i += used
            continue
        cur["paras"].append(para_text(items[i]))
        i += 1
    flush()

    # troppo pochi / troppi capitoli: ricostruisco a blocchi
    if len(chapters) < 3 or len(chapters) > 700:
        allp = [para_text(l) for l in items]
        chapters = [{"title": f"Parte {k + 1}", "group": "", "paras": ch}
                    for k, ch in enumerate(chunk(allp, 4500))]

    # capitoli enormi: li spezzo
    final = []
    for ch in chapters:
        if words(ch["paras"]) > 14000:
            parts = chunk(ch["paras"], 6000)
            for k, pp in enumerate(parts):
                final.append({"title": f"{ch['title']} ({k + 1}/{len(parts)})", "group": ch["group"], "paras": pp})
        else:
            final.append(ch)
    return final


# ----------------------------------------------------------------------------------------
# Costruzione del catalogo
# ----------------------------------------------------------------------------------------
def write_js(path, text):
    path.write_text(text, encoding="utf-8")


def process(b, raw):
    chs = parse_book(raw)
    wc = sum(words(c["paras"]) for c in chs)
    payload = [[c["title"], c["group"], c["paras"]] for c in chs]
    js = "window.__LIB.books[%s]=%s;" % (json.dumps(b["slug"]), json.dumps(payload, ensure_ascii=False,
                                                                       separators=(",", ":")))
    write_js(DATA / f"{b['slug']}.js", js)
    return dict(slug=b["slug"], title=b["title"], author=b["author"], lang=b["lang"], lib=b["lib"], cat=b["cat"],
                year=b["year"], blurb=b["blurb"], words=wc, chapters=len(chs), minutes=max(1, round(wc / 210)))


def conta(catalog, lib, lang):
    return sum(1 for c in catalog if c["lib"] == lib and c["lang"] == lang)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--solo", help="slug separati da virgola (prova veloce)")
    ap.add_argument("--no-riempi", action="store_true", help="non sostituire i libri mancanti")
    args = ap.parse_args()
    only = set(args.solo.split(",")) if args.solo else None

    DATA.mkdir(exist_ok=True)
    used, catalog, failed = set(), [], []
    todo = [b for b in BOOKS if not only or b["slug"] in only]
    print(f"\nLeggio · preparo {len(todo)} libri…\n", flush=True)
    for n, b in enumerate(todo, 1):
        print(f"[{n:>3}/{len(todo)}] {b['title']} — {b['author']} … ", end="", flush=True)
        try:
            raw, gid = get_raw(b, used)
        except Exception as e:  # noqa
            raw, gid = None, None
            print(f"errore ({e}) ", end="")
        if not raw:
            print("non trovato")
            failed.append(b)
            continue
        if gid:
            used.add(gid)
        item = process(b, raw)
        catalog.append(item)
        print(f"ok ({item['chapters']} capitoli, {item['words']:,} parole)".replace(",", "."), flush=True)

    # sostituzione automatica dei titoli mancanti, per far tornare i numeri
    sostituiti = []
    if not only and not args.no_riempi:
        piani = []
        for lib in ("alunni", "prof"):
            kids = lib == "alunni"
            it_q = ([{"languages": "it", "topic": t} for t in ("children", "fairy tales", "adventure", "juvenile")]
                    if kids else [{"languages": "it"}])
            piani.append((lib, "it", MIN_IT - conta(catalog, lib, "it"), it_q, "Altri classici"))
            for lang, nome in (("en", "English"), ("es", "Español")):
                q = ([{"languages": lang, "topic": "children"}] if kids else []) + [{"languages": lang}]
                piani.append((lib, lang, MAX_ALTRE - conta(catalog, lib, lang), q, nome))
        for lib, lang, need, qs, cat in piani:
            if need <= 0:
                continue
            print(f"\nMi mancano {need} libri ({lib}, {lang}): li sostituisco con altri classici…", flush=True)
            for b, raw in autofill(lib, lang, need, qs, used, cat):
                item = process(b, raw)
                catalog.append(item)
                sostituiti.append(item)
                print(f"   + {item['title']} — {item['author']}", flush=True)

    # se ho usato --solo, mantengo i libri già presenti
    if only and (DATA / "catalog.json").exists():
        old = json.loads((DATA / "catalog.json").read_text(encoding="utf-8"))
        have = {c["slug"] for c in catalog}
        catalog = [c for c in old if c["slug"] not in have and (DATA / f"{c['slug']}.js").exists()] + catalog
    order = {b["slug"]: i for i, b in enumerate(BOOKS)}
    catalog.sort(key=lambda c: order.get(c["slug"], 9999))
    (DATA / "catalog.json").write_text(json.dumps(catalog, ensure_ascii=False), encoding="utf-8")
    write_js(DATA / "catalog.js", "window.__LIB={catalog:%s,books:{}};" % json.dumps(catalog, ensure_ascii=False))

    righe = ["", "RIEPILOGO", "---------"]
    for lib in ("alunni", "prof"):
        it, en, es = (conta(catalog, lib, x) for x in ("it", "en", "es"))
        righe.append(f"{lib.upper():<8} italiani {it:>3} (obiettivo {MIN_IT}+) · inglesi {en} · spagnoli {es} · totale {it + en + es}")
    righe.append(f"TOTALE SITO: {len(catalog)} libri")
    if sostituiti:
        righe.append(f"Sostituiti automaticamente: {len(sostituiti)}")
    mancanti = [b["title"] for b in failed]
    if mancanti:
        righe.append("Non trovati: " + "; ".join(mancanti))
    print("\n".join(righe))
    summ = os.environ.get("GITHUB_STEP_SUMMARY")
    if summ:
        with open(summ, "a", encoding="utf-8") as f:
            f.write("### Leggio\n```\n" + "\n".join(righe) + "\n```\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
