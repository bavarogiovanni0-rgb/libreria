(function () {
  'use strict';
  var D = window.__GIOCHI, LIB = window.__LIB;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  function h(tag, attrs, kids) {
    var e = document.createElement(tag);
    for (var k in (attrs || {})) {
      if (k === 'class') e.className = attrs[k];
      else if (k === 'text') e.textContent = attrs[k];
      else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), attrs[k]);
      else e.setAttribute(k, attrs[k]);
    }
    (kids || []).forEach(function (c) { if (c != null) e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return e;
  }
  function shuffle(a) { a = a.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  var store = {
    get: function (k, d) { try { var v = localStorage.getItem('leggio:' + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem('leggio:' + k, JSON.stringify(v)); } catch (e) {} }
  };
  var root, lib = 'alunni';
  function best(id) { return (store.get('giochi', {})[id + ':' + lib]) || 0; }
  function saveBest(id, stars) { var g = store.get('giochi', {}); if ((g[id + ':' + lib] || 0) < stars) { g[id + ':' + lib] = stars; store.set('giochi', g); } }
  function starsFor(pct) { return pct >= .9 ? 3 : pct >= .65 ? 2 : pct >= .35 ? 1 : 0; }
  function starStr(n) { return '★★★'.slice(0, n) + '☆☆☆'.slice(0, 3 - n); }
  function libBooks() { return (LIB.catalog || []).filter(function (b) { return b.lib === lib && b.lang === 'it' && b.author; }); }

  var GAMES = [
    { id: 'compr', e: '📖', n: 'Comprensione', d: 'Leggi un testo e rispondi alle domande', h: 28, run: compr },
    { id: 'riordina', e: '🧩', n: 'Riordina la frase', d: 'Metti le parole nell\'ordine giusto', h: 200, run: riordina },
    { id: 'completa', e: '✏️', n: 'Completa', d: 'Scegli la parola giusta', h: 160, run: completa },
    { id: 'autore', e: '🕵️', n: 'Chi l\'ha scritto?', d: 'Indovina l\'autore dei libri della biblioteca', h: 330, run: autore },
    { id: 'memory', e: '🃏', n: 'Memory dei libri', d: 'Abbina ogni libro al suo autore', h: 282, run: memory }
  ];

  function clear() { root.innerHTML = ''; }
  function top(title, onBack) {
    return h('div', { class: 'g-top' }, [
      h('button', { class: 'btn back', onclick: onBack, text: '← ' + (onBack === menu ? 'Sala giochi' : 'Indietro') }),
      h('h2', { class: 'g-title', text: title })
    ]);
  }

  function menu() {
    clear();
    root.appendChild(h('div', { class: 'g-hero' }, [
      h('p', { class: 'kicker', text: lib === 'prof' ? 'Livello prof' : 'Livello alunni' }),
      h('h1', { text: '🎮 Sala giochi' }),
      h('p', { class: 'lead', text: 'Esercizi di lettura e lingua, per allenarti giocando. Guadagna fino a tre stelle in ogni gioco!' })
    ]));
    var grid = h('div', { class: 'g-grid' });
    GAMES.forEach(function (g, i) {
      var b = best(g.id);
      grid.appendChild(h('button', { class: 'g-card', style: '--h:' + g.h + ';animation-delay:' + (i * 60) + 'ms', onclick: function () { g.run(); } }, [
        h('span', { class: 'g-emoji', text: g.e }), h('strong', { text: g.n }), h('span', { text: g.d }),
        h('em', { class: 'g-stars', text: starStr(b) })
      ]));
    });
    root.appendChild(grid);
  }

  /* ---- Motore quiz: elenco di domande a risposta multipla ---- */
  function quiz(id, title, items, opts) {
    opts = opts || {};
    var i = 0, score = 0;
    function next() {
      if (i >= items.length) return end();
      var it = items[i], answered = false;
      var order = it.o.length > 2 ? shuffle(it.o.map(function (_, k) { return k; })) : it.o.map(function (_, k) { return k; });
      clear();
      root.appendChild(top(title, opts.back || menu));
      if (opts.before) root.appendChild(opts.before);
      root.appendChild(h('div', { class: 'g-prog' }, [h('i', { style: 'width:' + Math.round(i / items.length * 100) + '%' })]));
      var box = h('div', { class: 'g-q' }, [h('p', { class: 'g-qn', text: 'Domanda ' + (i + 1) + ' di ' + items.length }), h('h3', { text: it.d })]);
      var fb = h('div', { class: 'g-fb', 'aria-live': 'polite' });
      var btns = [];
      order.forEach(function (k) {
        var b = h('button', { class: 'g-opt', text: it.o[k], onclick: function () {
          if (answered) return; answered = true;
          var ok = k === it.a;
          if (ok) score++;
          b.classList.add(ok ? 'ok' : 'no');
          if (!ok) btns[order.indexOf(it.a)].classList.add('ok');
          btns.forEach(function (x) { x.disabled = true; });
          fb.textContent = ok ? '✔ Esatto!' : '✘ Non proprio: la risposta giusta è «' + it.o[it.a] + '».';
          fb.className = 'g-fb show ' + (ok ? 'ok' : 'no');
          var nx = h('button', { class: 'btn primary g-next', text: i + 1 < items.length ? 'Avanti →' : 'Vedi il risultato', onclick: function () { i++; next(); } });
          box.appendChild(nx); nx.focus({ preventScroll: true });
        } });
        btns.push(b);
      });
      box.appendChild(h('div', { class: 'g-opts' }, btns));
      box.appendChild(fb);
      root.appendChild(box);
      window.scrollTo(0, 0);
    }
    function end() { result(id, title, score, items.length, function () { quiz(id, title, shuffle(items), opts); }, opts.back); }
    next();
  }

  function result(id, title, score, total, again, back) {
    var st = starsFor(score / total); saveBest(id, st);
    clear();
    root.appendChild(top(title, back || menu));
    var msg = st === 3 ? 'Fantastico!' : st === 2 ? 'Bravo!' : st === 1 ? 'Buon inizio!' : 'Riprova, ce la puoi fare!';
    root.appendChild(h('div', { class: 'g-end' }, [
      h('div', { class: 'g-bigstars', text: starStr(st) }),
      h('h3', { text: msg }),
      h('p', { text: 'Punteggio: ' + score + ' su ' + total }),
      h('div', { class: 'g-endbtns' }, [
        h('button', { class: 'btn primary', onclick: again, text: '↻ Rigioca' }),
        h('button', { class: 'btn', onclick: menu, text: 'Sala giochi' })
      ])
    ]));
    window.scrollTo(0, 0);
  }

  /* ---- 1. Comprensione ---- */
  function compr() {
    clear();
    root.appendChild(top('Comprensione', menu));
    root.appendChild(h('p', { class: 'g-hint', text: 'Scegli un testo da leggere:' }));
    var grid = h('div', { class: 'g-grid' });
    D.testi[lib].forEach(function (t, i) {
      var done = (store.get('giochi', {})['compr' + i + ':' + lib]) || 0;
      grid.appendChild(h('button', { class: 'g-card', style: '--h:' + (28 + i * 70) + ';animation-delay:' + (i * 60) + 'ms', onclick: function () { leggi(i); } }, [
        h('span', { class: 'g-emoji', text: t.e }), h('strong', { text: t.t }),
        h('span', { text: t.q.length + ' domande' }), h('em', { class: 'g-stars', text: starStr(done) })
      ]));
    });
    root.appendChild(grid);
  }
  function leggi(i) {
    var t = D.testi[lib][i];
    clear();
    root.appendChild(top(t.t, compr));
    var art = h('article', { class: 'g-text' }, t.txt.map(function (p) { return h('p', { text: p }); }));
    root.appendChild(art);
    root.appendChild(h('button', { class: 'btn primary g-go', text: 'Ho letto: rispondi alle domande →', onclick: function () {
      var items = t.q.map(function (q) { return q; });
      var det = h('details', { class: 'g-recall' }, [h('summary', { text: '📖 Rileggi il testo' })].concat(t.txt.map(function (p) { return h('p', { text: p }); })));
      var key = 'compr' + i;
      quiz(key, t.t, items, { back: compr, before: det });
    } }));
    window.scrollTo(0, 0);
  }

  /* ---- 2. Riordina la frase ---- */
  function riordina() {
    var frasi = shuffle(D.frasi[lib]).slice(0, 6), i = 0, score = 0;
    function next() {
      if (i >= frasi.length) return result('riordina', 'Riordina la frase', score, frasi.length, riordina);
      var target = frasi[i], words = target.split(' '), done = false, tries = 0;
      var pool = shuffle(words.map(function (w, k) { return { w: w, k: k }; }));
      if (pool.map(function (x) { return x.w; }).join(' ') === target) pool = shuffle(pool);
      var chosen = [];
      clear();
      root.appendChild(top('Riordina la frase', menu));
      root.appendChild(h('div', { class: 'g-prog' }, [h('i', { style: 'width:' + Math.round(i / frasi.length * 100) + '%' })]));
      var line = h('div', { class: 'g-line' });
      var bank = h('div', { class: 'g-bank' });
      var fb = h('div', { class: 'g-fb', 'aria-live': 'polite' });
      var box = h('div', { class: 'g-q' }, [h('p', { class: 'g-qn', text: 'Frase ' + (i + 1) + ' di ' + frasi.length }), h('h3', { text: 'Tocca le parole nell\'ordine giusto' }), line, bank, fb]);
      var ctrl = h('div', { class: 'g-endbtns' }, [
        h('button', { class: 'btn', text: '↺ Ricomincia', onclick: function () { if (!done) { chosen = []; draw(); } } })
      ]);
      box.appendChild(ctrl);
      function finish(ok) {
        done = true;
        if (ok) { score += tries === 0 ? 1 : 0.5; }
        fb.textContent = ok ? '✔ Perfetto!' : '✘ La frase giusta era: «' + target + '»';
        fb.className = 'g-fb show ' + (ok ? 'ok' : 'no');
        ctrl.innerHTML = '';
        ctrl.appendChild(h('button', { class: 'btn primary g-next', text: i + 1 < frasi.length ? 'Avanti →' : 'Vedi il risultato', onclick: function () { i++; next(); } }));
      }
      function draw() {
        line.innerHTML = ''; bank.innerHTML = '';
        chosen.forEach(function (x, idx) {
          line.appendChild(h('button', { class: 'g-word in', text: x.w, onclick: function () { if (done) return; chosen.splice(idx, 1); draw(); } }));
        });
        if (!chosen.length) line.appendChild(h('span', { class: 'g-ph', text: 'La frase comparirà qui…' }));
        pool.forEach(function (x) {
          var used = chosen.indexOf(x) > -1;
          var wb = h('button', { class: 'g-word' + (used ? ' used' : ''), text: x.w, onclick: function () {
            if (done || used) return; chosen.push(x); draw();
            if (chosen.length === pool.length) {
              var ok = chosen.map(function (c) { return c.w; }).join(' ') === target;
              if (ok) finish(true);
              else { tries++; if (tries >= 2) finish(false); else { fb.textContent = 'Non è ancora giusta: riprova!'; fb.className = 'g-fb show no'; chosen = []; setTimeout(draw, 700); } }
            }
          } });
          wb.disabled = used; bank.appendChild(wb);
        });
      }
      root.appendChild(box); draw(); window.scrollTo(0, 0);
    }
    next();
  }

  /* ---- 3. Completa ---- */
  function completa() {
    var items = shuffle(D.complete[lib]).slice(0, 8).map(function (c) { return { d: c[0].replace('___', '＿＿＿'), o: c[1], a: c[2] }; });
    quiz('completa', 'Completa', items);
  }

  /* ---- 4. Chi l'ha scritto? ---- */
  function autore() {
    var bs = libBooks(), authors = [];
    bs.forEach(function (b) { if (authors.indexOf(b.author) < 0) authors.push(b.author); });
    if (bs.length < 4 || authors.length < 4) {
      clear(); root.appendChild(top('Chi l\'ha scritto?', menu));
      root.appendChild(h('div', { class: 'g-end' }, [h('h3', { text: 'I libri non sono ancora pronti' }), h('p', { text: 'Questo gioco usa i libri della biblioteca: torna tra poco!' })]));
      return;
    }
    var items = shuffle(bs).slice(0, 8).map(function (b) {
      var wrong = shuffle(authors.filter(function (a) { return a !== b.author; })).slice(0, 3);
      return { d: 'Chi ha scritto «' + b.title + '»?', o: [b.author].concat(wrong), a: 0 };
    });
    quiz('autore', 'Chi l\'ha scritto?', items);
  }

  /* ---- 5. Memory ---- */
  function memory() {
    var bs = libBooks(), pairs = [], seenA = {}, seenT = {};
    shuffle(bs).forEach(function (b) {
      if (pairs.length < 6 && !seenA[b.author] && !seenT[b.title] && b.title.length < 38) { pairs.push([b.title, b.author]); seenA[b.author] = seenT[b.title] = 1; }
    });
    if (pairs.length < 6) pairs = shuffle(D.coppie).slice(0, 6);
    var cards = [];
    pairs.forEach(function (p, k) { cards.push({ k: k, t: p[0], kind: 'libro' }); cards.push({ k: k, t: p[1], kind: 'autore' }); });
    cards = shuffle(cards);
    var open = [], found = 0, moves = 0, lock = false;
    clear(); root.appendChild(top('Memory dei libri', menu));
    var info = h('p', { class: 'g-hint', text: 'Trova le coppie libro 📕 e autore ✍️. Mosse: 0' });
    var grid = h('div', { class: 'g-mem' });
    root.appendChild(info); root.appendChild(grid);
    cards.forEach(function (c) {
      var el = h('button', { class: 'g-mc ' + c.kind, 'aria-label': 'Carta coperta' }, [
        h('span', { class: 'g-mf' }, [h('i', { text: c.kind === 'libro' ? '📕' : '✍️' })]),
        h('span', { class: 'g-mb', text: c.t })
      ]);
      el.addEventListener('click', function () {
        if (lock || el.classList.contains('up') || el.classList.contains('done')) return;
        el.classList.add('up'); open.push([c, el]);
        if (open.length === 2) {
          moves++; info.textContent = 'Trova le coppie libro 📕 e autore ✍️. Mosse: ' + moves;
          var a = open[0], b = open[1];
          if (a[0].k === b[0].k) {
            a[1].classList.add('done'); b[1].classList.add('done'); open = []; found++;
            if (found === pairs.length) setTimeout(function () {
              var sc = Math.max(0, Math.round(10 - Math.max(0, moves - pairs.length) * 0.6));
              result('memory', 'Memory dei libri', sc, 10, memory);
            }, 700);
          } else { lock = true; setTimeout(function () { a[1].classList.remove('up'); b[1].classList.remove('up'); open = []; lock = false; }, 1000); }
        }
      });
      grid.appendChild(el);
    });
  }

  window.__GIOCHI.open = function (el, l) { root = el; lib = l === 'prof' ? 'prof' : 'alunni'; menu(); };
})();
