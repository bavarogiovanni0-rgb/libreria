window.__GIOCHI = {
  testi: {
    alunni: [
      { t: 'Il faro di Marta', e: '🏮', txt: [
        'Marta ha undici anni e vive con il nonno in una casetta bianca, sopra una scogliera. Accanto alla casa c\'è un vecchio faro. Ogni sera il nonno sale le scale e accende la grande lampada, che gira lentamente e manda la luce lontano, sul mare.',
        'Una notte di nebbia fitta, Marta sente il suono di una sirena. È una barca di pescatori che ha perso la rotta. Corre al faro e vede che la lampada si è fermata: l\'ingranaggio è rotto e il nonno ha un forte raffreddore e dorme.',
        'Marta non lo sveglia. Trova una manovella e gira la lampada a mano, per più di un\'ora, finché le braccia non le fanno male. Alla fine i pescatori vedono la luce e arrivano sani e salvi in porto. La mattina dopo il nonno la abbraccia e le dice: «Sei tu il vero guardiano del faro».'
      ], q: [
        { d: 'Con chi vive Marta?', o: ['Con il nonno', 'Con i genitori', 'Con una zia', 'Da sola'], a: 0 },
        { d: 'Che cosa succede alla lampada del faro?', o: ['Si spegne per il vento', 'Smette di girare perché si rompe l\'ingranaggio', 'Viene rubata', 'Cade in mare'], a: 1 },
        { d: 'Come fa Marta ad aiutare i pescatori?', o: ['Chiama la guardia costiera', 'Accende un fuoco sulla scogliera', 'Gira la lampada a mano con una manovella', 'Sveglia il nonno'], a: 2 },
        { d: 'Vero o falso? Marta sveglia il nonno per chiedere aiuto.', o: ['Vero', 'Falso'], a: 1 },
        { d: 'Vero o falso? Quella notte c\'era la nebbia.', o: ['Vero', 'Falso'], a: 0 },
        { d: 'Perché il nonno dice a Marta «Sei tu il vero guardiano del faro»?', o: ['Perché ha salvato la barca con il suo coraggio', 'Perché sa riparare gli ingranaggi', 'Perché dorme poco', 'Perché abita vicino al mare'], a: 0 }
      ]},
      { t: 'Il riccio e lo scoiattolo', e: '🦔', txt: [
        'In un bosco vivevano un riccio di nome Ettore e uno scoiattolo di nome Lilla. In autunno Lilla correva da un albero all\'altro per raccogliere noci e ghiande. «Fai presto!» diceva a Ettore. «L\'inverno è lungo!»',
        'Ettore, invece, camminava piano. Non raccoglieva noci: preparava un nido di foglie secche sotto una grossa radice, perché i ricci passano l\'inverno a dormire. Lilla rideva: «Tu dormirai tutto l\'inverno e non mangerai niente!».',
        'Quando arrivò la neve, Lilla scoprì di aver dimenticato dove aveva nascosto molte noci. Aveva fame e freddo. Ettore dormiva tranquillo, perché il suo corpo era fatto per quel sonno. A primavera il riccio si svegliò, si stiracchiò e trovò Lilla magra e stanca. Insieme cercarono le noci perdute e da quel giorno Lilla smise di prendere in giro gli amici.'
      ], q: [
        { d: 'Che cosa fa Lilla in autunno?', o: ['Dorme in una tana', 'Raccoglie noci e ghiande', 'Costruisce un nido di foglie', 'Parte per un viaggio'], a: 1 },
        { d: 'Perché Ettore prepara un nido di foglie?', o: ['Perché ama le foglie', 'Perché i ricci passano l\'inverno a dormire', 'Perché ha paura dello scoiattolo', 'Perché non sa raccogliere le noci'], a: 1 },
        { d: 'Quale problema ha Lilla durante l\'inverno?', o: ['Ha dimenticato dove ha nascosto molte noci', 'Si è ammalata di raffreddore', 'Ha perso la coda', 'Non trova più Ettore'], a: 0 },
        { d: 'Vero o falso? Ettore soffre la fame durante l\'inverno.', o: ['Vero', 'Falso'], a: 1 },
        { d: 'Che cosa impara Lilla alla fine?', o: ['A correre più veloce', 'A non prendere in giro chi è diverso', 'A dormire tutto l\'inverno', 'A cucinare le noci'], a: 1 }
      ]},
      { t: 'Il pianeta Zuk', e: '🚀', txt: [
        'L\'astronave «Cometa» atterrò su un pianeta viola. Il capitano Ilaria e il suo robot Bip scesero con cautela. Il cielo era verde e dalla terra spuntavano funghi grandi come case.',
        'All\'improvviso comparve una creatura bassa e rotonda, con tre occhi e un cappello di foglie. «Io sono Zuk e questo è il mio pianeta» disse, con una vocina acuta. «Da mille anni nessuno viene a trovarmi. Volete giocare a nascondino?»',
        'Ilaria rise. Giocarono per tutto il pomeriggio, ma Bip si nascondeva sempre nello stesso posto, dentro un fungo, e Zuk lo trovava subito. Prima di ripartire, Zuk regalò a Ilaria una pietra luminosa: «Se mi vorrai rivedere, tienila vicino al cuore e ti troverò io».'
      ], q: [
        { d: 'Di che colore è il pianeta su cui atterra la «Cometa»?', o: ['Rosso', 'Viola', 'Blu', 'Giallo'], a: 1 },
        { d: 'Chi è Bip?', o: ['Il capitano', 'Un abitante del pianeta', 'Il robot di Ilaria', 'Un fungo parlante'], a: 2 },
        { d: 'Come sono fatti i funghi del pianeta?', o: ['Piccoli come bottoni', 'Grandi come case', 'Luminosi', 'Verdi'], a: 1 },
        { d: 'Vero o falso? Zuk non riceve visite da molto tempo.', o: ['Vero', 'Falso'], a: 0 },
        { d: 'Che cosa regala Zuk a Ilaria?', o: ['Un cappello di foglie', 'Un fungo', 'Una pietra luminosa', 'Un robot'], a: 2 }
      ]},
      { t: 'La gara degli aquiloni', e: '🪁', txt: [
        'Ogni anno, il primo sabato di aprile, il paese di Valle Alta organizza la gara degli aquiloni. Vince chi riesce a farlo salire più in alto e a tenerlo in aria più a lungo.',
        'Tommaso aveva costruito il suo aquilone con carta rossa e due cannucce, ma il vento era troppo debole e l\'aquilone ricadeva sempre per terra. Gli altri bambini lo guardavano e qualcuno rideva.',
        'La sua amica Sofia gli disse: «Prova a correre in salita, sul prato in alto». Tommaso salì sulla collina, trovò un vento più forte e il suo aquilone volò altissimo. Non arrivò primo, ma fu l\'unico a restare in cielo fino al tramonto, e per questo la giuria gli consegnò un premio speciale.'
      ], q: [
        { d: 'Quando si svolge la gara?', o: ['Il primo sabato di aprile', 'In estate', 'Il primo gennaio', 'Ogni domenica'], a: 0 },
        { d: 'Perché l\'aquilone di Tommaso ricade a terra?', o: ['È troppo pesante', 'Il vento è troppo debole', 'Si rompe il filo', 'Qualcuno lo tira'], a: 1 },
        { d: 'Quale consiglio gli dà Sofia?', o: ['Di cambiare aquilone', 'Di rinunciare', 'Di andare sul prato in alto', 'Di chiedere aiuto alla giuria'], a: 2 },
        { d: 'Vero o falso? Tommaso arriva primo nella gara.', o: ['Vero', 'Falso'], a: 1 },
        { d: 'Perché Tommaso riceve un premio speciale?', o: ['Perché ha l\'aquilone più bello', 'Perché è rimasto in cielo fino al tramonto', 'Perché ha aiutato Sofia', 'Perché è il più piccolo'], a: 1 }
      ]}
    ],
    prof: [
      { t: 'Gutenberg e la stampa', e: '🖨️', txt: [
        'Prima della metà del Quattrocento i libri in Europa erano copiati a mano, soprattutto dai monaci amanuensi nei monasteri. Un solo volume poteva richiedere mesi di lavoro e costava quanto un piccolo patrimonio, perciò la lettura restava un privilegio di pochi.',
        'Intorno al 1450, a Magonza, Johannes Gutenberg mise a punto un sistema di stampa a caratteri mobili metallici: le singole lettere, fuse in lega, potevano essere composte in righe, inchiostrate e pressate su carta, e poi riutilizzate. La cosiddetta Bibbia a 42 linee, stampata intorno al 1455, è considerata il primo grande libro prodotto con questa tecnica in Europa.',
        'In pochi decenni la stampa si diffuse in tutto il continente. A Venezia lavorò Aldo Manuzio, che introdusse formati più piccoli e maneggevoli, simili ai nostri libri tascabili, e rese popolare il carattere corsivo. Con libri più economici crebbero l\'alfabetizzazione e la circolazione delle idee: la stampa contribuì così in modo decisivo alla cultura rinascimentale e alla Riforma.'
      ], q: [
        { d: 'Perché prima della stampa la lettura era un privilegio di pochi?', o: ['Perché i libri erano vietati', 'Perché copiare un libro a mano era lungo e costoso', 'Perché si scriveva solo in latino', 'Perché mancava la carta'], a: 1 },
        { d: 'In che cosa consiste l\'innovazione di Gutenberg?', o: ['Nell\'inventare la carta', 'Nell\'uso di caratteri mobili metallici riutilizzabili', 'Nella traduzione della Bibbia', 'Nell\'invenzione dell\'inchiostro'], a: 1 },
        { d: 'Che cosa introdusse a Venezia Aldo Manuzio?', o: ['Il primo libro stampato', 'Formati più piccoli e il carattere corsivo', 'La stampa a colori', 'Le biblioteche pubbliche'], a: 1 },
        { d: 'Vero o falso? Secondo il testo, la stampa fece crescere l\'alfabetizzazione.', o: ['Vero', 'Falso'], a: 0 },
        { d: 'Che cosa si può dedurre dal testo?', o: ['I libri a stampa erano più costosi di quelli copiati a mano', 'La stampa favorì la diffusione delle idee', 'I monaci continuarono a produrre la maggior parte dei libri', 'La Riforma non ebbe legami con la stampa'], a: 1 }
      ]},
      { t: 'Dante e il volgare', e: '🪶', txt: [
        'Dante Alighieri nacque a Firenze nel 1265 e morì a Ravenna nel 1321. Coinvolto nelle lotte politiche cittadine, nel 1302 fu condannato all\'esilio e non tornò mai più nella sua città: trascorse gli ultimi anni di vita ospite di varie corti dell\'Italia settentrionale.',
        'All\'epoca la lingua della cultura era il latino, mentre il volgare era considerato adatto a temi più semplici. Dante, invece, scelse di scrivere la sua opera maggiore in volgare fiorentino. Nel trattato De vulgari eloquentia sostenne che una lingua viva poteva diventare strumento nobile di poesia e di pensiero.',
        'La Commedia è divisa in tre cantiche (Inferno, Purgatorio, Paradiso) di trentatré canti ciascuna, più un canto introduttivo. L\'aggettivo «divina» le fu attribuito più tardi dai lettori. Proprio perché scritta in volgare, l\'opera raggiunse un pubblico molto più ampio e contribuì a fare del fiorentino la base della lingua italiana.'
      ], q: [
        { d: 'Che cosa accadde a Dante nel 1302?', o: ['Fu incoronato poeta', 'Fu condannato all\'esilio', 'Terminò la Commedia', 'Tornò a Firenze'], a: 1 },
        { d: 'Perché scegliere il volgare fu una decisione importante?', o: ['Perché era più semplice da scrivere', 'Perché il latino era vietato', 'Perché permise all\'opera di raggiungere un pubblico più ampio', 'Perché nessuno parlava latino'], a: 2 },
        { d: 'Quante cantiche compongono la Commedia?', o: ['Due', 'Tre', 'Quattro', 'Cento'], a: 1 },
        { d: 'Vero o falso? Secondo il testo, l\'aggettivo «divina» fu scelto da Dante stesso.', o: ['Vero', 'Falso'], a: 1 },
        { d: 'Che funzione ha il De vulgari eloquentia nel ragionamento del testo?', o: ['Elenca i canti della Commedia', 'Sostiene la dignità del volgare come lingua poetica', 'Racconta l\'esilio di Dante', 'Descrive la politica fiorentina'], a: 1 }
      ]},
      { t: 'La biblioteca di Alessandria', e: '🏛️', txt: [
        'La Biblioteca di Alessandria d\'Egitto fu fondata nel III secolo a.C. sotto la dinastia dei Tolomei, nell\'ambito del Museo, un centro di studio dove lavoravano matematici, astronomi, poeti e filologi. L\'ambizione era raccogliere i libri di tutto il mondo conosciuto.',
        'Secondo diverse fonti antiche, le navi che attraccavano nel porto dovevano consegnare i rotoli che avevano a bordo: questi venivano copiati, e agli stranieri spesso restava la copia mentre l\'originale entrava in biblioteca. Studiosi come Eratostene, che calcolò con buona approssimazione la circonferenza della Terra, vi lavorarono.',
        'L\'immagine di un unico, grande incendio che avrebbe distrutto tutto è però semplificata. Gli storici ritengono che il declino sia stato lento: tagli ai finanziamenti, crisi politiche, scontri militari e il disinteresse dei governanti contribuirono, nei secoli, alla perdita di gran parte del patrimonio.'
      ], q: [
        { d: 'Sotto quale dinastia fu fondata la Biblioteca?', o: ['Dei Faraoni', 'Dei Tolomei', 'Dei Romani', 'Dei Persiani'], a: 1 },
        { d: 'Che cosa dovevano fare le navi che attraccavano nel porto?', o: ['Pagare un dazio', 'Consegnare i rotoli che avevano a bordo per copiarli', 'Portare nuovi studiosi', 'Lasciare l\'equipaggio ad Alessandria'], a: 1 },
        { d: 'Che cosa sostiene il testo sulla fine della Biblioteca?', o: ['Fu distrutta da un solo incendio', 'Il declino fu lento e dovuto a più cause', 'Non è mai esistita', 'Fu trasferita a Roma'], a: 1 },
        { d: 'Vero o falso? Eratostene viene citato come esempio di studioso che lavorò ad Alessandria.', o: ['Vero', 'Falso'], a: 0 },
        { d: 'Quale parola del testo indica uno studioso dei testi antichi?', o: ['Astronomo', 'Filologo', 'Matematico', 'Poeta'], a: 1 }
      ]},
      { t: 'Manzoni e la lingua', e: '📜', txt: [
        'I promessi sposi di Alessandro Manzoni uscì in una prima edizione nel 1827 e in una versione definitiva tra il 1840 e il 1842. Tra le due edizioni l\'autore riscrisse profondamente la lingua del romanzo.',
        'Manzoni era convinto che l\'Italia, politicamente divisa, avesse bisogno anche di una lingua comune e viva, che tutti potessero capire. Individuò il modello nel fiorentino parlato dalle persone colte, e per questo, dopo un soggiorno a Firenze, si dedicò a una revisione che eliminò molte forme lombarde e letterarie. La metafora che descrive questo lavoro è quella del «risciacquare i panni in Arno».',
        'Il risultato fu un italiano chiaro, più vicino al parlato. Il romanzo, adottato poi nelle scuole dell\'Italia unita, contribuì in modo notevole alla diffusione di una lingua nazionale, anche se il dibattito sulla «questione della lingua» proseguì a lungo.'
      ], q: [
        { d: 'Che cosa fece Manzoni tra la prima edizione e quella definitiva?', o: ['Cambiò la trama', 'Riscrisse profondamente la lingua del romanzo', 'Aggiunse nuovi personaggi', 'Tradusse il testo in latino'], a: 1 },
        { d: 'Quale modello linguistico scelse?', o: ['Il latino', 'Il dialetto lombardo', 'Il fiorentino parlato dalle persone colte', 'Il siciliano'], a: 2 },
        { d: 'Che cosa significa, nel contesto, «risciacquare i panni in Arno»?', o: ['Lavare i vestiti nel fiume', 'Ripulire la lingua avvicinandola al fiorentino', 'Trasferirsi a Firenze', 'Scrivere un nuovo romanzo'], a: 1 },
        { d: 'Vero o falso? Il testo afferma che la questione della lingua fu risolta subito dopo il romanzo.', o: ['Vero', 'Falso'], a: 1 },
        { d: 'Qual è l\'idea di fondo di Manzoni?', o: ['La lingua letteraria deve restare lontana dal parlato', 'Un paese diviso ha bisogno di una lingua comune e viva', 'Il dialetto è superiore all\'italiano', 'Il romanzo deve usare più latinismi'], a: 1 }
      ]}
    ]
  },
  frasi: {
    alunni: ['Il gatto dorme sul divano rosso', 'Oggi andiamo al parco con i nostri amici', 'La maestra ci ha letto una storia bellissima', 'Il pirata nascose il tesoro sotto una grande palma', 'Quando piove resto a casa a leggere un libro', 'Il drago sputò fuoco sulla torre del castello', 'Mia sorella ha trovato una chiave d\'oro in giardino', 'Nel bosco vivono volpi, cervi e piccoli scoiattoli'],
    prof: ['Il narratore descrive i fatti con distacco e ironia', 'Benché fosse stanco, il viaggiatore proseguì il cammino fino all\'alba', 'La lettura di un classico ci invita a guardare il presente con occhi nuovi', 'Se avessi saputo la verità, non avrei mai accettato quell\'incarico', 'Lo scrittore affidò al protagonista i propri dubbi sul destino dell\'uomo', 'Nonostante le critiche, l\'opera fu accolta con grande entusiasmo dal pubblico', 'Il poeta cerca nelle parole una forma capace di durare nel tempo', 'Pur non conoscendo la città, trovammo subito la via giusta']
  },
  complete: {
    alunni: [
      ['Gli amici ___ arrivati tardi alla festa.', ['sono', 'hanno', 'abbiamo'], 0],
      ['Ho comprato un ___ zaino.', ['bello', 'bel', 'belli'], 0],
      ['Lo scoiattolo è ___ veloce del riccio.', ['più', 'molto', 'tanto'], 0],
      ['I bambini ___ giocare nel cortile.', ['vogliono', 'vuole', 'voglio'], 0],
      ['La mia amica ___ molti libri.', ['legge', 'leggono', 'leggi'], 0],
      ['Io ___ sempre i compiti prima di giocare.', ['faccio', 'fai', 'fa'], 0],
      ['Oggi ci sono ___ nuvole in cielo.', ['molte', 'molti', 'molto'], 0],
      ['Ho incontrato ___ amici al parco.', ['i miei', 'il mio', 'la mia'], 0],
      ['Il bosco è ___ di alberi altissimi.', ['pieno', 'piena', 'pieni'], 0],
      ['Ieri io ___ al mare con i miei cugini.', ['sono andato', 'ho andato', 'ero andare'], 0]
    ],
    prof: [
      ['Credo che Dante ___ il più grande poeta italiano.', ['sia', 'fosse stato', 'sarà'], 0],
      ['Se avessi più tempo, ___ tutti i classici.', ['leggerei', 'leggo', 'leggerò'], 0],
      ['Il libro ___ ti parlavo è sul tavolo.', ['di cui', 'che', 'quale'], 0],
      ['È necessario che tu ___ attenzione.', ['faccia', 'fai', 'farai'], 0],
      ['Ho letto un romanzo ___ protagonista è un pirata.', ['il cui', 'che', 'di cui'], 0],
      ['Nel Medioevo i libri erano copiati a mano dagli ___.', ['amanuensi', 'tipografi', 'archivisti'], 0],
      ['Sinonimo di «effimero»:', ['passeggero', 'eterno', 'vasto'], 0],
      ['Contrario di «prodigo»:', ['avaro', 'generoso', 'ricco'], 0],
      ['«Ineluttabile» significa:', ['inevitabile', 'piacevole', 'dubbioso'], 0],
      ['«Mi hai spezzato il cuore» è una:', ['metafora', 'similitudine', 'rima'], 0],
      ['Passato remoto di «vedere» (io):', ['vidi', 'vedei', 'veddi'], 0]
    ]
  },
  coppie: [['Pinocchio', 'Collodi'], ['Cuore', 'De Amicis'], ['I promessi sposi', 'Manzoni'], ['Il Principe', 'Machiavelli'], ['Il Decameron', 'Boccaccio'], ['La Divina Commedia', 'Dante'], ['Il Canzoniere', 'Petrarca'], ['Il fu Mattia Pascal', 'Pirandello']]
};
